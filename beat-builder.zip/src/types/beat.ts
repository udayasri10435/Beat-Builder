export type SampleCategory = 'kick' | 'snare' | 'hihat' | 'openhat' | 'perc' | 'vocal' | 'melodic' | 'bass';

export interface SampleDefinition {
  id: string;
  name: string;
  category: SampleCategory;
  color: string; // Accent color hex
  keyTrigger: string; // Keyboard hotkey (e.g. '1', '2', 'Q', etc.)
  defaultPitch: number; // semitones (-12 to +12)
  description: string;
  // Synthesis parameters
  synthType: 'sub_kick' | 'punch_snare' | 'closed_hat' | 'open_hat' | 'wood_perc' | 'vocal_chop' | 'synth_keys' | 'analog_bass';
}

export interface SamplePack {
  id: string;
  weekNumber: number;
  title: string;
  subtitle: string;
  genre: string;
  bpmDefault: number;
  description: string;
  artGradient: string;
  rules: string[];
  submissionDeadline: string; // ISO date or countdown label
  samples: SampleDefinition[];
}

export interface TrackData {
  id: string;
  sampleId: string;
  name: string;
  steps: boolean[]; // 16 or 32 steps boolean
  volume: number; // 0 to 100
  pan: number; // -50 to 50
  pitch: number; // -12 to +12 semitones
  muted: boolean;
  soloed: boolean;
}

export interface BeatProject {
  id: string;
  title: string;
  producer: string;
  packId: string;
  bpm: number;
  swing: number; // 0 to 50
  stepCount: number; // 16, 32, or 64 steps
  patternCount: number; // 1 to 4 patterns chained
  tracks: TrackData[];
  createdAt: number;
  tags?: string[];
}

export interface CommunityBeat {
  id: string;
  title: string;
  producer: string;
  producerHandle: string;
  avatarSeed: string;
  packId: string;
  weekNumber: number;
  bpm: number;
  durationSeconds: number; // Max 30.0s
  votes: number;
  hypeCount: number;
  rank: number;
  rankDelta: number; // positive = climbed, negative = dropped, 0 = same, 999 = new
  badges: string[]; // e.g. "Cleanest Mix", "Groove Master", "Staff Pick"
  submittedAt: string;
  project: BeatProject;
  hasVoted?: boolean;
  hasHyped?: boolean;
}

export type ActiveTab = 'studio' | 'charts' | 'battle' | 'packs';
