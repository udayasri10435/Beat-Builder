import { SamplePack } from '../types/beat';

export const SAMPLE_PACKS: SamplePack[] = [
  {
    id: 'pack_week_39',
    weekNumber: 39,
    title: 'Tokyo Rain Lo-Fi',
    subtitle: 'Warm analog tape saturation, midnight vinyl crackle, and jazzy chops',
    genre: 'Lo-Fi Chillhop / Boom Bap',
    bpmDefault: 86,
    description: 'Captured from rainy alleyways and vintage Japanese cassette decks. Create a relaxing or head-bobbing 30-second beat with this nostalgic sonic palette.',
    artGradient: 'from-amber-600/30 via-purple-900/40 to-slate-950',
    rules: [
      'Strict 30.0-second limit (official timekeeping enforced)',
      'All sounds must originate from the Tokyo Rain pack',
      'Minimum 3 distinct tracks programmed',
      'No external third-party sample uploads'
    ],
    submissionDeadline: '2026-10-04T23:59:59Z',
    samples: [
      {
        id: 's_kick_rain',
        name: 'Tape 808 Kick',
        category: 'kick',
        color: '#f59e0b',
        keyTrigger: '1',
        defaultPitch: 0,
        description: 'Deep warm sub kick with vintage tape compression bump',
        synthType: 'sub_kick'
      },
      {
        id: 's_snare_dust',
        name: 'Rain Rim & Snare',
        category: 'snare',
        color: '#fbbf24',
        keyTrigger: '2',
        defaultPitch: 0,
        description: 'Dry wooden rimshot layered with subtle vinyl dust',
        synthType: 'punch_snare'
      },
      {
        id: 's_hat_closed',
        name: 'Damp Closed Hat',
        category: 'hihat',
        color: '#10b981',
        keyTrigger: '3',
        defaultPitch: 0,
        description: 'Muffled 16th-note hi-hat with analog roll-off',
        synthType: 'closed_hat'
      },
      {
        id: 's_hat_open',
        name: 'Sizzle Open Hat',
        category: 'openhat',
        color: '#34d399',
        keyTrigger: '4',
        defaultPitch: 0,
        description: 'Airy cymbal sizzle that chokes when closed hat strikes',
        synthType: 'open_hat'
      },
      {
        id: 's_perc_wood',
        name: 'Bamboo Shaker',
        category: 'perc',
        color: '#06b6d4',
        keyTrigger: '5',
        defaultPitch: 0,
        description: 'Snappy organic wood click with natural room reflection',
        synthType: 'wood_perc'
      },
      {
        id: 's_vocal_subway',
        name: 'Subway Vocal Chop',
        category: 'vocal',
        color: '#a855f7',
        keyTrigger: '6',
        defaultPitch: 0,
        description: 'Ethereal pitched vocal harmonic with lush hall reverb',
        synthType: 'vocal_chop'
      },
      {
        id: 's_rhodes_chord',
        name: 'Midnight Rhodes Stab',
        category: 'melodic',
        color: '#ec4899',
        keyTrigger: '7',
        defaultPitch: 0,
        description: 'Minor 9th electric piano chord with tremolo flutter',
        synthType: 'synth_keys'
      },
      {
        id: 's_sub_upright',
        name: 'Warm Sub Bass',
        category: 'bass',
        color: '#e11d48',
        keyTrigger: '8',
        defaultPitch: 0,
        description: 'Rounded upright bass pluck with deep harmonic foundation',
        synthType: 'analog_bass'
      }
    ]
  },
  {
    id: 'pack_week_38',
    weekNumber: 38,
    title: 'Cyber Neon Trap',
    subtitle: 'Brutal sliding 808s, surgical laser claps, and dystopian synths',
    genre: 'Futuristic Trap / Cyberpunk',
    bpmDefault: 138,
    description: 'Forged in neon subterranean frequencies. High energy, rolling rapid hats, and heavy low-end impact.',
    artGradient: 'from-cyan-600/30 via-blue-900/40 to-slate-950',
    rules: [
      'Strict 30.0-second limit',
      'Exclusive Cyber Neon pack components only',
      'Final weekly chart archived'
    ],
    submissionDeadline: 'Archived',
    samples: [
      {
        id: 's_cyber_808',
        name: 'Neuro 808 Sub',
        category: 'kick',
        color: '#06b6d4',
        keyTrigger: '1',
        defaultPitch: 0,
        description: 'Distorted sliding 808 kick that rattles monitors',
        synthType: 'sub_kick'
      },
      {
        id: 's_cyber_clap',
        name: 'Laser Snare Clap',
        category: 'snare',
        color: '#38bdf8',
        keyTrigger: '2',
        defaultPitch: 0,
        description: 'Surgical snare with stereo pre-shift slap',
        synthType: 'punch_snare'
      },
      {
        id: 's_cyber_hat_c',
        name: 'Matrix Rapid Hat',
        category: 'hihat',
        color: '#818cf8',
        keyTrigger: '3',
        defaultPitch: 0,
        description: 'Ultra-crisp metallic click built for triplet rolls',
        synthType: 'closed_hat'
      },
      {
        id: 's_cyber_hat_o',
        name: 'Pulse Crash',
        category: 'openhat',
        color: '#c084fc',
        keyTrigger: '4',
        defaultPitch: 0,
        description: 'Resonant white-noise laser burst',
        synthType: 'open_hat'
      },
      {
        id: 's_cyber_perc',
        name: 'Industrial Glitch',
        category: 'perc',
        color: '#f43f5e',
        keyTrigger: '5',
        defaultPitch: 0,
        description: 'Modular synth glitch transient',
        synthType: 'wood_perc'
      },
      {
        id: 's_cyber_vox',
        name: 'Android Chant Chop',
        category: 'vocal',
        color: '#fb7185',
        keyTrigger: '6',
        defaultPitch: 0,
        description: 'Formant robotic vocal accent',
        synthType: 'vocal_chop'
      },
      {
        id: 's_cyber_lead',
        name: 'Neon Arp Lead',
        category: 'melodic',
        color: '#f59e0b',
        keyTrigger: '7',
        defaultPitch: 0,
        description: 'Square-wave detuned synthesizer lead pluck',
        synthType: 'synth_keys'
      },
      {
        id: 's_cyber_acid',
        name: 'Acid Bassline 303',
        category: 'bass',
        color: '#10b981',
        keyTrigger: '8',
        defaultPitch: 0,
        description: 'Squelchy resonant bass run',
        synthType: 'analog_bass'
      }
    ]
  },
  {
    id: 'pack_week_37',
    weekNumber: 37,
    title: 'Dust & Soul 90s',
    subtitle: 'Golden age crate digging, brass stabs, and punchy breakbeats',
    genre: 'Classic Hip-Hop / 90s Boom Bap',
    bpmDefault: 92,
    description: 'Raw SP-1200 grit and 12-bit crunch. Recreate the golden era of east coast hip hop rhythm sections.',
    artGradient: 'from-amber-700/30 via-stone-800/40 to-slate-950',
    rules: [
      'Strict 30.0-second limit',
      'Exclusive Dust & Soul pack components only',
      'Final weekly chart archived'
    ],
    submissionDeadline: 'Archived',
    samples: [
      {
        id: 's_dust_kick',
        name: 'SP-12 Thump Kick',
        category: 'kick',
        color: '#d97706',
        keyTrigger: '1',
        defaultPitch: 0,
        description: 'Raw punchy punch kick sampled off vinyl dust',
        synthType: 'sub_kick'
      },
      {
        id: 's_dust_snare',
        name: 'Crisp Crate Snare',
        category: 'snare',
        color: '#ea580c',
        keyTrigger: '2',
        defaultPitch: 0,
        description: 'Classic crack snare with acoustic room tone',
        synthType: 'punch_snare'
      },
      {
        id: 's_dust_hat_c',
        name: 'Gritty Ghost Hat',
        category: 'hihat',
        color: '#84cc16',
        keyTrigger: '3',
        defaultPitch: 0,
        description: 'Soft swing hat for tight pocket grooves',
        synthType: 'closed_hat'
      },
      {
        id: 's_dust_hat_o',
        name: 'Vinyl Ride Cymbal',
        category: 'openhat',
        color: '#22c55e',
        keyTrigger: '4',
        defaultPitch: 0,
        description: 'Long sizzling brass ride',
        synthType: 'open_hat'
      },
      {
        id: 's_dust_perc',
        name: 'Cowbell Perc',
        category: 'perc',
        color: '#06b6d4',
        keyTrigger: '5',
        defaultPitch: 0,
        description: 'Vintage 808 tuned cowbell click',
        synthType: 'wood_perc'
      },
      {
        id: 's_dust_vox',
        name: 'Soul Cry Vocal Chop',
        category: 'vocal',
        color: '#8b5cf6',
        keyTrigger: '6',
        defaultPitch: 0,
        description: 'High falsetto soul cry with spring reverb',
        synthType: 'vocal_chop'
      },
      {
        id: 's_dust_brass',
        name: 'Horn Section Hit',
        category: 'melodic',
        color: '#f43f5e',
        keyTrigger: '7',
        defaultPitch: 0,
        description: 'Stab of vintage muted trumpet and sax quartet',
        synthType: 'synth_keys'
      },
      {
        id: 's_dust_bass',
        name: 'Motown Bass Groove',
        category: 'bass',
        color: '#eab308',
        keyTrigger: '8',
        defaultPitch: 0,
        description: 'Deep warm flatwound electric bass',
        synthType: 'analog_bass'
      }
    ]
  }
];
