import { CommunityBeat, TrackData } from '../types/beat';

// Preset beat patterns for Tokyo Rain Lo-Fi (Week 39)
const createTracks = (
  kickSteps: number[],
  snareSteps: number[],
  hatSteps: number[],
  openHatSteps: number[],
  percSteps: number[],
  voxSteps: number[],
  rhodesSteps: number[],
  bassSteps: number[]
): TrackData[] => {
  const stepArray = (active: number[], length: number = 32): boolean[] => {
    const arr = new Array(length).fill(false);
    active.forEach(idx => {
      if (idx < length) arr[idx] = true;
    });
    return arr;
  };

  return [
    {
      id: 't_kick',
      sampleId: 's_kick_rain',
      name: 'Tape 808 Kick',
      steps: stepArray(kickSteps),
      volume: 88,
      pan: 0,
      pitch: 0,
      muted: false,
      soloed: false
    },
    {
      id: 't_snare',
      sampleId: 's_snare_dust',
      name: 'Rain Rim & Snare',
      steps: stepArray(snareSteps),
      volume: 85,
      pan: 0,
      pitch: 0,
      muted: false,
      soloed: false
    },
    {
      id: 't_hat',
      sampleId: 's_hat_closed',
      name: 'Damp Closed Hat',
      steps: stepArray(hatSteps),
      volume: 72,
      pan: -15,
      pitch: 0,
      muted: false,
      soloed: false
    },
    {
      id: 't_openhat',
      sampleId: 's_hat_open',
      name: 'Sizzle Open Hat',
      steps: stepArray(openHatSteps),
      volume: 68,
      pan: 20,
      pitch: 0,
      muted: false,
      soloed: false
    },
    {
      id: 't_perc',
      sampleId: 's_perc_wood',
      name: 'Bamboo Shaker',
      steps: stepArray(percSteps),
      volume: 65,
      pan: 25,
      pitch: 1,
      muted: false,
      soloed: false
    },
    {
      id: 't_vocal',
      sampleId: 's_vocal_subway',
      name: 'Subway Vocal Chop',
      steps: stepArray(voxSteps),
      volume: 76,
      pan: -10,
      pitch: 0,
      muted: false,
      soloed: false
    },
    {
      id: 't_rhodes',
      sampleId: 's_rhodes_chord',
      name: 'Midnight Rhodes Stab',
      steps: stepArray(rhodesSteps),
      volume: 80,
      pan: 5,
      pitch: 0,
      muted: false,
      soloed: false
    },
    {
      id: 't_bass',
      sampleId: 's_sub_upright',
      name: 'Warm Sub Bass',
      steps: stepArray(bassSteps),
      volume: 82,
      pan: 0,
      pitch: 0,
      muted: false,
      soloed: false
    }
  ];
};

export const INITIAL_COMMUNITY_BEATS: CommunityBeat[] = [
  {
    id: 'beat_1',
    title: 'Midnight in Shibuya',
    producer: 'Kaizen_Audio',
    producerHandle: '@kaizen_beats',
    avatarSeed: 'kaizen',
    packId: 'pack_week_39',
    weekNumber: 39,
    bpm: 84,
    durationSeconds: 28.5,
    votes: 428,
    hypeCount: 682,
    rank: 1,
    rankDelta: 2,
    badges: ['Top Ranked', 'Cleanest Mix'],
    submittedAt: '2026-09-27T18:20:00Z',
    project: {
      id: 'proj_1',
      title: 'Midnight in Shibuya',
      producer: 'Kaizen_Audio',
      packId: 'pack_week_39',
      bpm: 84,
      swing: 24,
      stepCount: 32,
      patternCount: 2,
      createdAt: 1727461200000,
      tags: ['Lo-Fi', 'Night Drive', 'Soulful'],
      tracks: createTracks(
        [0, 6, 10, 16, 22, 26, 28], // kick
        [4, 12, 20, 28], // snare
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], // hat
        [14, 30], // open hat
        [2, 7, 18, 23], // perc
        [12, 28], // vocal
        [0, 8, 16, 24], // rhodes
        [0, 6, 16, 22] // bass
      )
    }
  },
  {
    id: 'beat_2',
    title: 'Neon Umbrella Reflections',
    producer: 'Sora_Sound',
    producerHandle: '@sora_lofi',
    avatarSeed: 'sora',
    packId: 'pack_week_39',
    weekNumber: 39,
    bpm: 88,
    durationSeconds: 27.2,
    votes: 384,
    hypeCount: 540,
    rank: 2,
    rankDelta: -1,
    badges: ['Groove Master'],
    submittedAt: '2026-09-27T20:45:00Z',
    project: {
      id: 'proj_2',
      title: 'Neon Umbrella Reflections',
      producer: 'Sora_Sound',
      packId: 'pack_week_39',
      bpm: 88,
      swing: 32,
      stepCount: 32,
      patternCount: 2,
      createdAt: 1727469900000,
      tags: ['Boom Bap', 'Rainy', 'Chill'],
      tracks: createTracks(
        [0, 3, 10, 16, 19, 26], // kick
        [4, 12, 20, 28], // snare
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], // hat
        [6, 22], // open hat
        [3, 11, 19, 27], // perc
        [4, 20], // vox
        [0, 6, 16, 22], // rhodes
        [0, 8, 16, 24] // bass
      )
    }
  },
  {
    id: 'beat_3',
    title: 'Warm Ramen Steam',
    producer: 'BeatAlchemist',
    producerHandle: '@alchemist_tap',
    avatarSeed: 'alchemist',
    packId: 'pack_week_39',
    weekNumber: 39,
    bpm: 82,
    durationSeconds: 29.2,
    votes: 312,
    hypeCount: 420,
    rank: 3,
    rankDelta: 4,
    badges: ['Wildest Chops', 'Staff Pick'],
    submittedAt: '2026-09-28T02:15:00Z',
    project: {
      id: 'proj_3',
      title: 'Warm Ramen Steam',
      producer: 'BeatAlchemist',
      packId: 'pack_week_39',
      bpm: 82,
      swing: 28,
      stepCount: 32,
      patternCount: 2,
      createdAt: 1727489700000,
      tags: ['Downtempo', 'Acoustic', 'Warm'],
      tracks: createTracks(
        [0, 8, 14, 16, 24, 30], // kick
        [4, 12, 20, 28], // snare
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], // hat
        [12, 28], // open hat
        [6, 14, 22, 30], // perc
        [0, 8, 16, 24], // vox
        [0, 4, 16, 20], // rhodes
        [0, 8, 16, 24] // bass
      )
    }
  },
  {
    id: 'beat_4',
    title: 'Tape Deck Hiss & Honey',
    producer: 'KiloHertz',
    producerHandle: '@kilohz_prod',
    avatarSeed: 'kilo',
    packId: 'pack_week_39',
    weekNumber: 39,
    bpm: 85,
    durationSeconds: 28.2,
    votes: 275,
    hypeCount: 390,
    rank: 4,
    rankDelta: 0,
    badges: ['Vocal Flip'],
    submittedAt: '2026-09-28T09:30:00Z',
    project: {
      id: 'proj_4',
      title: 'Tape Deck Hiss & Honey',
      producer: 'KiloHertz',
      packId: 'pack_week_39',
      bpm: 85,
      swing: 18,
      stepCount: 32,
      patternCount: 2,
      createdAt: 1727515800000,
      tags: ['Dusty', 'Tape', 'Chords'],
      tracks: createTracks(
        [0, 7, 16, 23, 26], // kick
        [4, 12, 20, 28], // snare
        [0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 17, 18, 20, 22, 24, 26, 28, 30], // hat rolls
        [8, 24], // open hat
        [4, 12, 20, 28], // perc
        [2, 10, 18, 26], // vox
        [0, 8, 16, 24], // rhodes
        [0, 7, 16, 23] // bass
      )
    }
  },
  {
    id: 'beat_5',
    title: 'Under the Overpass',
    producer: 'SubtleWave',
    producerHandle: '@subtlewave',
    avatarSeed: 'subtle',
    packId: 'pack_week_39',
    weekNumber: 39,
    bpm: 90,
    durationSeconds: 26.6,
    votes: 230,
    hypeCount: 310,
    rank: 5,
    rankDelta: -2,
    badges: ['Heavy Sub'],
    submittedAt: '2026-09-28T14:10:00Z',
    project: {
      id: 'proj_5',
      title: 'Under the Overpass',
      producer: 'SubtleWave',
      packId: 'pack_week_39',
      bpm: 90,
      swing: 15,
      stepCount: 32,
      patternCount: 2,
      createdAt: 1727532600000,
      tags: ['Underground', 'Raw', 'Sub'],
      tracks: createTracks(
        [0, 10, 16, 26], // kick
        [4, 12, 20, 28], // snare
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], // hat
        [14, 30], // open hat
        [7, 15, 23, 31], // perc
        [6, 22], // vox
        [2, 10, 18, 26], // rhodes
        [0, 10, 16, 26] // bass
      )
    }
  },
  {
    id: 'beat_6',
    title: 'Vinyl Petals Floating',
    producer: 'Haruto_99',
    producerHandle: '@haruto99',
    avatarSeed: 'haruto',
    packId: 'pack_week_39',
    weekNumber: 39,
    bpm: 80,
    durationSeconds: 30.0,
    votes: 195,
    hypeCount: 265,
    rank: 6,
    rankDelta: 999, // New entry
    badges: ['Fresh Drop'],
    submittedAt: '2026-09-28T19:00:00Z',
    project: {
      id: 'proj_6',
      title: 'Vinyl Petals Floating',
      producer: 'Haruto_99',
      packId: 'pack_week_39',
      bpm: 80,
      swing: 25,
      stepCount: 32,
      patternCount: 2,
      createdAt: 1727550000000,
      tags: ['Ambient', 'Jazzy', '30s Master'],
      tracks: createTracks(
        [0, 6, 16, 22], // kick
        [4, 12, 20, 28], // snare
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30], // hat
        [10, 26], // open hat
        [1, 9, 17, 25], // perc
        [14, 30], // vox
        [0, 8, 16, 24], // rhodes
        [0, 8, 16, 24] // bass
      )
    }
  }
];
