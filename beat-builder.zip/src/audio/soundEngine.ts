// Web Audio API Synthesis and Playback Engine for Beat Builder
import { SampleDefinition, TrackData } from '../types/beat';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private masterFilter: BiquadFilterNode | null = null;
  private masterCompressor: DynamicsCompressorNode | null = null;
  private analyser: AnalyserNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;

  // Active open-hat voice for choking
  private activeOpenHats: { stop: (time: number) => void }[] = [];

  constructor() {
    // Lazily initialized on user interaction
  }

  public init() {
    if (this.ctx) return;
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioCtx();

    // Create Master Chain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.85, this.ctx.currentTime);

    this.masterFilter = this.ctx.createBiquadFilter();
    this.masterFilter.type = 'allpass';
    this.masterFilter.frequency.setValueAtTime(20000, this.ctx.currentTime);

    this.masterCompressor = this.ctx.createDynamicsCompressor();
    this.masterCompressor.threshold.setValueAtTime(-14, this.ctx.currentTime);
    this.masterCompressor.knee.setValueAtTime(6, this.ctx.currentTime);
    this.masterCompressor.ratio.setValueAtTime(4, this.ctx.currentTime);
    this.masterCompressor.attack.setValueAtTime(0.005, this.ctx.currentTime);
    this.masterCompressor.release.setValueAtTime(0.1, this.ctx.currentTime);

    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.smoothingTimeConstant = 0.8;

    // Connect: masterFilter -> masterCompressor -> masterGain -> analyser -> destination
    this.masterFilter.connect(this.masterCompressor);
    this.masterCompressor.connect(this.masterGain);
    this.masterGain.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);

    // Pre-generate noise buffer for snares/hats
    this.generateNoiseBuffer();
  }

  private generateNoiseBuffer() {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * 2; // 2 seconds of noise
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buffer;
  }

  public getAudioContext(): AudioContext {
    if (!this.ctx) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx!;
  }

  public getAnalyser(): AnalyserNode | null {
    if (!this.ctx) this.init();
    return this.analyser;
  }

  public setMasterVolume(vol: number) {
    if (!this.masterGain || !this.ctx) return;
    const clamped = Math.max(0, Math.min(1, vol));
    this.masterGain.gain.setTargetAtTime(clamped, this.ctx.currentTime, 0.03);
  }

  // DJ filter knob: value between -100 and +100
  // -100: lowpass at 200Hz, 0: bypass (allpass/20kHz), +100: highpass at 4000Hz
  public setMasterFilter(value: number) {
    if (!this.masterFilter || !this.ctx) return;
    const time = this.ctx.currentTime;
    if (value < -2) {
      // Lowpass mode
      this.masterFilter.type = 'lowpass';
      // Exponential mapping from 20000Hz down to 250Hz
      const norm = (value + 100) / 98; // 0 to 1
      const freq = 250 * Math.pow(20000 / 250, norm);
      this.masterFilter.frequency.setTargetAtTime(Math.max(150, freq), time, 0.03);
      this.masterFilter.Q.setTargetAtTime(2.5, time, 0.03);
    } else if (value > 2) {
      // Highpass mode
      this.masterFilter.type = 'highpass';
      // Exponential mapping from 20Hz up to 5000Hz
      const norm = value / 100; // 0 to 1
      const freq = 30 * Math.pow(5000 / 30, norm);
      this.masterFilter.frequency.setTargetAtTime(freq, time, 0.03);
      this.masterFilter.Q.setTargetAtTime(2.0, time, 0.03);
    } else {
      this.masterFilter.type = 'allpass';
      this.masterFilter.frequency.setTargetAtTime(20000, time, 0.03);
      this.masterFilter.Q.setTargetAtTime(0, time, 0.03);
    }
  }

  /**
   * Triggers a specific sample sound
   */
  public playSample(
    sample: SampleDefinition,
    pitchOffset: number = 0,
    volume: number = 80,
    panVal: number = 0,
    timeOffset: number = 0
  ) {
    const ctx = this.getAudioContext();
    const startTime = ctx.currentTime + Math.max(0, timeOffset);

    // Channel routing: Track Gain -> Pan -> Master Filter
    const trackGain = ctx.createGain();
    const normalizedVol = (volume / 100) * 0.9;
    trackGain.gain.setValueAtTime(normalizedVol, startTime);

    const panNode = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (panNode) {
      panNode.pan.setValueAtTime(Math.max(-1, Math.min(1, panVal / 50)), startTime);
      trackGain.connect(panNode);
      panNode.connect(this.masterFilter!);
    } else {
      trackGain.connect(this.masterFilter!);
    }

    const pitchRatio = Math.pow(2, (sample.defaultPitch + pitchOffset) / 12);

    switch (sample.synthType) {
      case 'sub_kick':
        this.synthKick(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'punch_snare':
        this.synthSnare(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'closed_hat':
        // Choke any ringing open hats
        this.chokeOpenHats(startTime);
        this.synthClosedHat(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'open_hat':
        this.synthOpenHat(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'wood_perc':
        this.synthPerc(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'vocal_chop':
        this.synthVocalChop(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'synth_keys':
        this.synthKeys(ctx, trackGain, startTime, pitchRatio);
        break;
      case 'analog_bass':
        this.synthBass(ctx, trackGain, startTime, pitchRatio);
        break;
      default:
        this.synthKick(ctx, trackGain, startTime, pitchRatio);
    }
  }

  private chokeOpenHats(time: number) {
    for (const hat of this.activeOpenHats) {
      hat.stop(time);
    }
    this.activeOpenHats = [];
  }

  // --- SYNTHESIZERS ---

  // Punchy 808 sub kick
  private synthKick(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    const startFreq = 160 * pitchRatio;
    const endFreq = 42 * pitchRatio;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, time);
    osc.frequency.exponentialRampToValueAtTime(endFreq, time + 0.08);

    // Initial click transient
    const click = ctx.createOscillator();
    const clickGain = ctx.createGain();
    click.type = 'triangle';
    click.frequency.setValueAtTime(320 * pitchRatio, time);
    click.frequency.exponentialRampToValueAtTime(30, time + 0.025);
    clickGain.gain.setValueAtTime(0.7, time);
    clickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.025);
    click.connect(clickGain);
    clickGain.connect(dest);
    click.start(time);
    click.stop(time + 0.03);

    // Main 808 decay
    gain.gain.setValueAtTime(1.0, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.45);

    osc.connect(gain);
    gain.connect(dest);
    osc.start(time);
    osc.stop(time + 0.46);
  }

  // Dual-layer snare
  private synthSnare(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    // 1. Tonal body
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(240 * pitchRatio, time);
    osc.frequency.exponentialRampToValueAtTime(85 * pitchRatio, time + 0.09);

    oscGain.gain.setValueAtTime(0.9, time);
    oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.14);
    osc.connect(oscGain);
    oscGain.connect(dest);
    osc.start(time);
    osc.stop(time + 0.15);

    // 2. Snappy Noise Rattle
    if (this.noiseBuffer) {
      const noise = ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;
      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.setValueAtTime(1200 * pitchRatio, time);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.8, time);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, time + 0.22);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(dest);
      noise.start(time);
      noise.stop(time + 0.23);
    }
  }

  // Tight closed hi-hat
  private synthClosedHat(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    if (!this.noiseBuffer) return;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;

    const bandpass = ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(8500 * pitchRatio, time);
    bandpass.Q.setValueAtTime(3.5, time);

    const highpass = ctx.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.setValueAtTime(7000 * pitchRatio, time);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.7, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);

    noise.connect(bandpass);
    bandpass.connect(highpass);
    highpass.connect(gain);
    gain.connect(dest);

    noise.start(time);
    noise.stop(time + 0.055);
  }

  // Sizzling open hi-hat
  private synthOpenHat(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    if (!this.noiseBuffer) return;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;

    const bandpass = ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(9200 * pitchRatio, time);
    bandpass.Q.setValueAtTime(2.8, time);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.65, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.38);

    noise.connect(bandpass);
    bandpass.connect(gain);
    gain.connect(dest);

    noise.start(time);
    noise.stop(time + 0.4);

    // Register active open hat so closed hat can choke it
    this.activeOpenHats.push({
      stop: (stopTime: number) => {
        gain.gain.cancelScheduledValues(stopTime);
        gain.gain.setValueAtTime(gain.gain.value, stopTime);
        gain.gain.linearRampToValueAtTime(0.001, stopTime + 0.015);
        try {
          noise.stop(stopTime + 0.02);
        } catch {
          // ignore if already stopped
        }
      }
    });
  }

  // Organic wood percussion / rim
  private synthPerc(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    const baseFreq = 780 * pitchRatio;
    osc.frequency.setValueAtTime(baseFreq * 1.5, time);
    osc.frequency.exponentialRampToValueAtTime(baseFreq, time + 0.015);

    gain.gain.setValueAtTime(0.85, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.07);

    osc.connect(gain);
    gain.connect(dest);
    osc.start(time);
    osc.stop(time + 0.08);
  }

  // Formant vocal harmonic chop
  private synthVocalChop(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    // Sawtooth source shaped by 2 formant filters
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    const fundamental = 330 * pitchRatio; // E4 range
    osc.frequency.setValueAtTime(fundamental, time);

    // Vibrato
    const vibrato = ctx.createOscillator();
    const vibratoGain = ctx.createGain();
    vibrato.frequency.setValueAtTime(5.5, time); // 5.5 Hz vibrato
    vibratoGain.gain.setValueAtTime(6 * pitchRatio, time);
    vibrato.connect(vibratoGain);
    vibratoGain.connect(osc.frequency);
    vibrato.start(time);
    vibrato.stop(time + 0.35);

    // Formant filter 1 ("Ah" vowel)
    const f1 = ctx.createBiquadFilter();
    f1.type = 'bandpass';
    f1.frequency.setValueAtTime(800 * pitchRatio, time);
    f1.Q.setValueAtTime(5, time);

    // Formant filter 2 ("Oh" vowel)
    const f2 = ctx.createBiquadFilter();
    f2.type = 'bandpass';
    f2.frequency.setValueAtTime(1400 * pitchRatio, time);
    f2.Q.setValueAtTime(6, time);

    const amp = ctx.createGain();
    amp.gain.setValueAtTime(0.01, time);
    amp.gain.linearRampToValueAtTime(0.7, time + 0.02);
    amp.gain.exponentialRampToValueAtTime(0.001, time + 0.32);

    osc.connect(f1);
    osc.connect(f2);
    f1.connect(amp);
    f2.connect(amp);
    amp.connect(dest);

    osc.start(time);
    osc.stop(time + 0.34);
  }

  // Electric piano / Synth chord pluck
  private synthKeys(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    const chordNotes = [0, 4, 7, 11]; // Major 7th / minor 9th harmonics
    const masterChordGain = ctx.createGain();
    masterChordGain.gain.setValueAtTime(0.35, time);
    masterChordGain.gain.exponentialRampToValueAtTime(0.001, time + 0.55);
    masterChordGain.connect(dest);

    chordNotes.forEach((semi, index) => {
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      const freq = 261.63 * Math.pow(2, semi / 12) * pitchRatio; // Base C4

      osc.type = index % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, time);

      // Tremolo / chorus detune
      if (index === 1) osc.detune.setValueAtTime(8, time);
      if (index === 2) osc.detune.setValueAtTime(-7, time);

      oscGain.gain.setValueAtTime(0.8 / chordNotes.length, time);
      oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.5);

      osc.connect(oscGain);
      oscGain.connect(masterChordGain);

      osc.start(time);
      osc.stop(time + 0.55);
    });
  }

  // Analog Sub / Pluck Bass
  private synthBass(ctx: BaseAudioContext, dest: AudioNode, time: number, pitchRatio: number) {
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    const baseFreq = 55 * pitchRatio; // A1
    osc.frequency.setValueAtTime(baseFreq, time);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(650 * pitchRatio, time);
    filter.frequency.exponentialRampToValueAtTime(110 * pitchRatio, time + 0.22);
    filter.Q.setValueAtTime(4.0, time);

    gain.gain.setValueAtTime(0.9, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.38);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(dest);

    osc.start(time);
    osc.stop(time + 0.4);
  }

  /**
   * Renders the beat pattern offline into a downloadable 30-second uncompressed WAV file
   */
  public async exportBeatToWav(
    tracks: TrackData[],
    samples: SampleDefinition[],
    bpm: number,
    swing: number,
    targetDurationSec: number = 30.0
  ): Promise<Blob> {
    const sampleRate = 44100;
    const duration = Math.min(30.0, Math.max(4.0, targetDurationSec));
    const offlineCtx = new OfflineAudioContext(2, sampleRate * duration, sampleRate);

    // Noise buffer for offline ctx
    const noiseBuffer = offlineCtx.createBuffer(1, sampleRate * 2, sampleRate);
    const noiseData = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseData.length; i++) {
      noiseData[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = noiseBuffer;

    const masterGain = offlineCtx.createGain();
    masterGain.gain.setValueAtTime(0.85, 0);

    const comp = offlineCtx.createDynamicsCompressor();
    comp.threshold.setValueAtTime(-14, 0);
    comp.knee.setValueAtTime(6, 0);
    comp.ratio.setValueAtTime(4, 0);
    comp.attack.setValueAtTime(0.005, 0);
    comp.release.setValueAtTime(0.1, 0);

    comp.connect(masterGain);
    masterGain.connect(offlineCtx.destination);

    // Calculate step timing
    const stepDuration = 60 / bpm / 4; // 16th note
    const totalPossibleSteps = Math.floor(duration / stepDuration);

    const sampleMap = new Map<string, SampleDefinition>();
    samples.forEach(s => sampleMap.set(s.id, s));

    tracks.forEach(track => {
      if (track.muted) return;
      const sample = sampleMap.get(track.sampleId);
      if (!sample) return;

      const trackGain = offlineCtx.createGain();
      const trackVol = (track.volume / 100) * 0.9;
      trackGain.gain.setValueAtTime(trackVol, 0);

      const panner = offlineCtx.createStereoPanner ? offlineCtx.createStereoPanner() : null;
      if (panner) {
        panner.pan.setValueAtTime(Math.max(-1, Math.min(1, track.pan / 50)), 0);
        trackGain.connect(panner);
        panner.connect(comp);
      } else {
        trackGain.connect(comp);
      }

      const pitchRatio = Math.pow(2, (sample.defaultPitch + track.pitch) / 12);

      // Loop steps up to totalPossibleSteps or 30s
      for (let sIdx = 0; sIdx < totalPossibleSteps; sIdx++) {
        const patternStep = sIdx % track.steps.length;
        if (!track.steps[patternStep]) continue;

        let time = sIdx * stepDuration;
        // Swing on odd 16th notes
        if (sIdx % 2 === 1 && swing > 0) {
          time += (swing / 100) * stepDuration * 0.5;
        }

        if (time >= duration - 0.05) break;

        // Trigger on offline ctx
        switch (sample.synthType) {
          case 'sub_kick':
            this.synthKick(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'punch_snare':
            this.synthSnare(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'closed_hat':
            this.synthClosedHat(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'open_hat':
            this.synthOpenHat(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'wood_perc':
            this.synthPerc(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'vocal_chop':
            this.synthVocalChop(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'synth_keys':
            this.synthKeys(offlineCtx, trackGain, time, pitchRatio);
            break;
          case 'analog_bass':
            this.synthBass(offlineCtx, trackGain, time, pitchRatio);
            break;
        }
      }
    });

    const renderedBuffer = await offlineCtx.startRendering();
    return this.audioBufferToWav(renderedBuffer);
  }

  // Converts AudioBuffer to WAV Blob
  private audioBufferToWav(buffer: AudioBuffer): Blob {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;
    const bytesPerSample = bitDepth / 8;
    const blockAlign = numChannels * bytesPerSample;

    const length = buffer.length * blockAlign;
    const bufferArray = new ArrayBuffer(44 + length);
    const view = new DataView(bufferArray);

    const writeString = (offset: number, str: string) => {
      for (let i = 0; i < str.length; i++) {
        view.setUint8(offset + i, str.charCodeAt(i));
      }
    };

    /* RIFF identifier */
    writeString(0, 'RIFF');
    /* file length */
    view.setUint32(4, 36 + length, true);
    /* RIFF type */
    writeString(8, 'WAVE');
    /* format chunk identifier */
    writeString(12, 'fmt ');
    /* format chunk length */
    view.setUint32(16, 16, true);
    /* sample format (raw) */
    view.setUint16(20, format, true);
    /* channel count */
    view.setUint16(22, numChannels, true);
    /* sample rate */
    view.setUint32(24, sampleRate, true);
    /* byte rate (sample rate * block align) */
    view.setUint32(28, sampleRate * blockAlign, true);
    /* block align (channel count * bytes per sample) */
    view.setUint16(32, blockAlign, true);
    /* bits per sample */
    view.setUint16(34, bitDepth, true);
    /* data chunk identifier */
    writeString(36, 'data');
    /* data chunk length */
    view.setUint32(40, length, true);

    // Interleave channels
    const channels = [];
    for (let c = 0; c < numChannels; c++) {
      channels.push(buffer.getChannelData(c));
    }

    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let c = 0; c < numChannels; c++) {
        let sample = channels[c][i];
        sample = Math.max(-1, Math.min(1, sample));
        view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
        offset += 2;
      }
    }

    return new Blob([view], { type: 'audio/wav' });
  }
}

export const soundEngine = new SoundEngine();
