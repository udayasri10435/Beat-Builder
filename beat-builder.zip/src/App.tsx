import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ActiveTab, CommunityBeat, SamplePack, TrackData, SampleDefinition } from './types/beat';
import { SAMPLE_PACKS } from './data/samplePacks';
import { INITIAL_COMMUNITY_BEATS } from './data/initialBeats';
import { soundEngine } from './audio/soundEngine';
import { Header } from './components/Header';
import { TransportBar } from './components/TransportBar';
import { SequencerGrid } from './components/SequencerGrid';
import { DrumPads } from './components/DrumPads';
import { TrackMixerRow } from './components/TrackMixerRow';
import { WeeklyCharts } from './components/WeeklyCharts';
import { BlindBattle } from './components/BlindBattle';
import { SamplePacksView } from './components/SamplePacksView';
import { SubmitBeatModal } from './components/SubmitBeatModal';
import { Sparkles, Trophy, Disc3, Info, CheckCircle2 } from 'lucide-react';

const STORAGE_KEY_BEATS = 'beat_builder_community_beats_v1';
const STEP_COUNT = 32; // 2 measures of 16th notes per pattern

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('studio');
  const [currentPack, setCurrentPack] = useState<SamplePack>(SAMPLE_PACKS[0]); // Week 39
  const [bpm, setBpm] = useState<number>(SAMPLE_PACKS[0].bpmDefault);
  const [swing, setSwing] = useState<number>(24);
  const [masterVolume, setMasterVolume] = useState<number>(0.85);
  const [filterValue, setFilterValue] = useState<number>(0);
  const [loopMode, setLoopMode] = useState<boolean>(true);
  const [activePattern, setActivePattern] = useState<number>(0);

  // Playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(0);
  const [playingCommunityBeatId, setPlayingCommunityBeatId] = useState<string | null>(null);

  // Export & modal state
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Community beats state (with localStorage fallback)
  const [communityBeats, setCommunityBeats] = useState<CommunityBeat[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_BEATS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_COMMUNITY_BEATS;
  });

  // Save community beats when changed
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_BEATS, JSON.stringify(communityBeats));
    } catch {
      // ignore
    }
  }, [communityBeats]);

  // Build initial default tracks for the active pack
  const createDefaultTracks = useCallback((pack: SamplePack): TrackData[] => {
    return pack.samples.map((sample, idx) => {
      const steps = new Array(STEP_COUNT).fill(false);
      // Give a few groove steps to start so it immediately sounds awesome
      if (sample.category === 'kick') {
        [0, 6, 10, 16, 22, 26].forEach(s => (steps[s] = true));
      } else if (sample.category === 'snare') {
        [4, 12, 20, 28].forEach(s => (steps[s] = true));
      } else if (sample.category === 'hihat') {
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30].forEach(s => (steps[s] = true));
      } else if (sample.category === 'openhat') {
        [14, 30].forEach(s => (steps[s] = true));
      } else if (sample.category === 'melodic' || sample.category === 'vocal') {
        [0, 16].forEach(s => (steps[s] = true));
      } else if (sample.category === 'bass') {
        [0, 6, 16, 22].forEach(s => (steps[s] = true));
      }

      return {
        id: `trk_${sample.id}`,
        sampleId: sample.id,
        name: sample.name,
        steps,
        volume: 82,
        pan: 0,
        pitch: 0,
        muted: false,
        soloed: false
      };
    });
  }, []);

  const [tracks, setTracks] = useState<TrackData[]>(() => createDefaultTracks(SAMPLE_PACKS[0]));

  // Toast feedback helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 3200);
  };

  // Switch pack
  const handleSelectPack = (pack: SamplePack) => {
    setCurrentPack(pack);
    setBpm(pack.bpmDefault);
    setTracks(createDefaultTracks(pack));
    showToast(`Loaded ${pack.title} (Week ${pack.weekNumber}) sample pack`);
  };

  // Reset to empty beat
  const handleNewBeat = () => {
    setTracks(prev =>
      prev.map(t => ({
        ...t,
        steps: new Array(STEP_COUNT).fill(false)
      }))
    );
    setCurrentStep(0);
    setCurrentTimeSec(0);
    showToast('Created clean new beat template');
  };

  // Track manipulation
  const handleToggleStep = (trackId: string, stepIndex: number) => {
    soundEngine.init();
    setTracks(prev =>
      prev.map(t => {
        if (t.id !== trackId) return t;
        const newSteps = [...t.steps];
        newSteps[stepIndex] = !newSteps[stepIndex];
        return { ...t, steps: newSteps };
      })
    );
  };

  const handleUpdateTrack = (trackId: string, updates: Partial<TrackData>) => {
    setTracks(prev =>
      prev.map(t => (t.id === trackId ? { ...t, ...updates } : t))
    );
  };

  const handleClearTrack = (trackId: string) => {
    setTracks(prev =>
      prev.map(t =>
        t.id === trackId ? { ...t, steps: new Array(STEP_COUNT).fill(false) } : t
      )
    );
  };

  const handleAuditionSample = (sample: SampleDefinition) => {
    const track = tracks.find(t => t.sampleId === sample.id);
    soundEngine.playSample(
      sample,
      track?.pitch || 0,
      track?.volume || 80,
      track?.pan || 0
    );
  };

  // Master effects hooks
  useEffect(() => {
    soundEngine.setMasterVolume(masterVolume);
  }, [masterVolume]);

  useEffect(() => {
    soundEngine.setMasterFilter(filterValue);
  }, [filterValue]);

  // Compute exact loop duration for 32 steps (or 2 patterns = ~64 steps)
  // Step duration in seconds = (60 / bpm / 4)
  const stepDurationSec = 60 / bpm / 4;
  const loopDurationSec = STEP_COUNT * stepDurationSec;
  // If looping up to 30.0s, repeat pattern
  const computedDurationSec = Math.min(30.0, loopDurationSec * (loopMode ? 2 : 1));

  // --- PRECISE WEB AUDIO LOOKAHEAD SEQUENCER SCHEDULER ---
  const timerRef = useRef<number | null>(null);
  const nextNoteTimeRef = useRef<number>(0);
  const currentStepRef = useRef<number>(0);
  const totalElapsedSecRef = useRef<number>(0);
  const isPlayingRef = useRef<boolean>(false);
  isPlayingRef.current = isPlaying;

  const tracksRef = useRef(tracks);
  tracksRef.current = tracks;
  const bpmRef = useRef(bpm);
  bpmRef.current = bpm;
  const swingRef = useRef(swing);
  swingRef.current = swing;
  const loopModeRef = useRef(loopMode);
  loopModeRef.current = loopMode;
  const currentPackRef = useRef(currentPack);
  currentPackRef.current = currentPack;

  const scheduleStep = useCallback(
    (stepNumber: number, time: number) => {
      const currentTracks = tracksRef.current;
      const pack = currentPackRef.current;
      const sampleMap = new Map<string, SampleDefinition>();
      pack.samples.forEach(s => sampleMap.set(s.id, s));

      const hasSolo = currentTracks.some(t => t.soloed);

      currentTracks.forEach(track => {
        const isEffectiveMuted = track.muted || (hasSolo && !track.soloed);
        if (isEffectiveMuted) return;

        const isStepOn = track.steps[stepNumber % track.steps.length];
        if (!isStepOn) return;

        const sample = sampleMap.get(track.sampleId);
        if (!sample) return;

        const audioCtx = soundEngine.getAudioContext();
        const timeOffset = Math.max(0, time - audioCtx.currentTime);

        soundEngine.playSample(
          sample,
          track.pitch,
          track.volume,
          track.pan,
          timeOffset
        );
      });
    },
    []
  );

  const scheduler = useCallback(() => {
    if (!isPlayingRef.current) return;
    const audioCtx = soundEngine.getAudioContext();
    const lookahead = 0.08; // 80ms lookahead
    const currentBpm = bpmRef.current;
    const stepDuration = 60 / currentBpm / 4;

    while (nextNoteTimeRef.current < audioCtx.currentTime + lookahead) {
      // Calculate swing offset on odd 16th notes
      let scheduledTime = nextNoteTimeRef.current;
      const isOdd = currentStepRef.current % 2 === 1;
      if (isOdd && swingRef.current > 0) {
        scheduledTime += (swingRef.current / 100) * stepDuration * 0.5;
      }

      scheduleStep(currentStepRef.current, scheduledTime);

      // Advance clock
      const stepIdx = currentStepRef.current;
      setCurrentStep(stepIdx);

      // Update elapsed seconds tracker (up to 30.0s max limit)
      totalElapsedSecRef.current += stepDuration;
      setCurrentTimeSec(Math.min(30.0, totalElapsedSecRef.current));

      // Check 30.0-second competition limit
      if (totalElapsedSecRef.current >= 30.0) {
        if (loopModeRef.current) {
          totalElapsedSecRef.current = 0;
          currentStepRef.current = 0;
        } else {
          // Reached limit, stop playback
          setIsPlaying(false);
          break;
        }
      } else {
        currentStepRef.current = (currentStepRef.current + 1) % STEP_COUNT;
      }

      nextNoteTimeRef.current += stepDuration;
    }

    if (isPlayingRef.current) {
      timerRef.current = window.setTimeout(scheduler, 25);
    }
  }, [scheduleStep]);

  const startPlayback = useCallback(() => {
    soundEngine.init();
    const audioCtx = soundEngine.getAudioContext();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    // Stop any community audition
    setPlayingCommunityBeatId(null);

    nextNoteTimeRef.current = audioCtx.currentTime + 0.05;
    currentStepRef.current = currentStep;
    totalElapsedSecRef.current = currentTimeSec;
    setIsPlaying(true);
  }, [currentStep, currentTimeSec]);

  const stopPlayback = useCallback(() => {
    setIsPlaying(false);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    setCurrentStep(0);
    setCurrentTimeSec(0);
    currentStepRef.current = 0;
    totalElapsedSecRef.current = 0;
  }, []);

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      setIsPlaying(false);
      if (timerRef.current) clearTimeout(timerRef.current);
    } else {
      startPlayback();
    }
  }, [isPlaying, startPlayback]);

  // Start scheduler loop when isPlaying turns true
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = window.setTimeout(scheduler, 25);
    } else {
      if (timerRef.current) clearTimeout(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isPlaying, scheduler]);

  // Spacebar hotkey to play/pause
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        e.preventDefault();
        togglePlay();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [togglePlay]);

  // Audition a Community Beat (in Charts or Blind Battle)
  const handleTogglePlayCommunityBeat = useCallback(
    (beat: CommunityBeat) => {
      soundEngine.init();

      if (playingCommunityBeatId === beat.id) {
        // Pause it
        setPlayingCommunityBeatId(null);
        setIsPlaying(false);
        if (timerRef.current) clearTimeout(timerRef.current);
        return;
      }

      // Stop sequencer DAW if running
      setIsPlaying(false);
      if (timerRef.current) clearTimeout(timerRef.current);

      setPlayingCommunityBeatId(beat.id);

      // Play community beat by simulating its tracks on the sound engine!
      const audioCtx = soundEngine.getAudioContext();
      if (audioCtx.state === 'suspended') audioCtx.resume();

      const beatBpm = beat.bpm;
      const stepDur = 60 / beatBpm / 4;
      const pack = SAMPLE_PACKS.find(p => p.id === beat.packId) || currentPack;
      const sampleMap = new Map<string, SampleDefinition>();
      pack.samples.forEach(s => sampleMap.set(s.id, s));

      let step = 0;
      let elapsed = 0;
      const maxDuration = beat.durationSeconds;

      const playAuditionLoop = () => {
        if (step * stepDur >= maxDuration) {
          setPlayingCommunityBeatId(null);
          return;
        }

        beat.project.tracks.forEach(t => {
          if (t.muted) return;
          if (t.steps[step % t.steps.length]) {
            const sample = sampleMap.get(t.sampleId);
            if (sample) {
              soundEngine.playSample(sample, t.pitch, t.volume, t.pan, 0);
            }
          }
        });

        step++;
        elapsed += stepDur;

        // Schedule next step if still auditioning
        const nextTimer = window.setTimeout(playAuditionLoop, stepDur * 1000);
        return nextTimer;
      };

      playAuditionLoop();
    },
    [playingCommunityBeatId, currentPack]
  );

  // Remix a beat: Loads its tracks & parameters directly into the studio DAW
  const handleRemixBeat = (beat: CommunityBeat) => {
    stopPlayback();
    setPlayingCommunityBeatId(null);

    // Switch pack if needed
    const targetPack = SAMPLE_PACKS.find(p => p.id === beat.packId) || currentPack;
    setCurrentPack(targetPack);
    setBpm(beat.bpm);
    setSwing(beat.project.swing || 20);

    // Deep clone tracks
    setTracks(JSON.parse(JSON.stringify(beat.project.tracks)));
    setActiveTab('studio');
    showToast(`Loaded "${beat.title}" into Studio DAW. Ready to remix!`);
  };

  // Upvote community beat
  const handleVote = (beatId: string) => {
    setCommunityBeats(prev =>
      prev.map(b => {
        if (b.id !== beatId) return b;
        const newVoted = !b.hasVoted;
        return {
          ...b,
          hasVoted: newVoted,
          votes: newVoted ? b.votes + 1 : Math.max(0, b.votes - 1)
        };
      })
    );
    showToast('Vote counted for the weekly chart!');
  };

  // Hype fire reaction
  const handleHype = (beatId: string) => {
    setCommunityBeats(prev =>
      prev.map(b => {
        if (b.id !== beatId) return b;
        const newHyped = !b.hasHyped;
        return {
          ...b,
          hasHyped: newHyped,
          hypeCount: newHyped ? b.hypeCount + 1 : Math.max(0, b.hypeCount - 1)
        };
      })
    );
    showToast('Sent fire hype to the producer!');
  };

  // New Submission Success
  const handleSubmissionSuccess = (newBeat: CommunityBeat) => {
    setCommunityBeats(prev => [newBeat, ...prev]);
    setActiveTab('charts');
    showToast(`Successfully entered "${newBeat.title}" into Week ${currentPack.weekNumber} charts!`);
  };

  // Lossless 30-Second WAV Export
  const handleExportWav = async () => {
    setIsExporting(true);
    soundEngine.init();
    try {
      showToast('Rendering uncompressed 30-second studio master...');
      const wavBlob = await soundEngine.exportBeatToWav(
        tracks,
        currentPack.samples,
        bpm,
        swing,
        30.0
      );

      const url = URL.createObjectURL(wavBlob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `BeatBuilder_Week${currentPack.weekNumber}_${bpm}BPM_30s_Master.wav`;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(url);

      showToast('WAV master downloaded successfully!');
    } catch (err) {
      console.error('WAV export error:', err);
      showToast('Export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Toast Notification Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-neutral-900 border border-amber-500/50 text-amber-200 text-xs font-semibold rounded-xl shadow-2xl animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 3-Zone Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onNewBeat={handleNewBeat}
        onSubmitClick={() => setIsSubmitModalOpen(true)}
        weekNumber={currentPack.weekNumber}
        packTitle={currentPack.title}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6 space-y-6">
        {/* VIEW 1: STUDIO DAW */}
        {activeTab === 'studio' && (
          <div className="space-y-6">
            {/* Active Challenge Notice Bar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-4 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>Week {currentPack.weekNumber} Challenge:</strong> Create the best 30.0-second beat with "{currentPack.title}"
                </span>
              </div>
              <button
                onClick={() => setActiveTab('packs')}
                className="text-amber-400 hover:text-amber-200 underline font-mono text-[11px] whitespace-nowrap"
              >
                Inspect Pack Sounds & Rules &rarr;
              </button>
            </div>

            {/* Master Transport & 30-Sec Clock */}
            <TransportBar
              isPlaying={isPlaying}
              onTogglePlay={togglePlay}
              onStop={stopPlayback}
              bpm={bpm}
              onBpmChange={setBpm}
              swing={swing}
              onSwingChange={setSwing}
              currentStep={currentStep}
              totalSteps={STEP_COUNT}
              currentTimeSec={currentTimeSec}
              targetMaxSeconds={30.0}
              masterVolume={masterVolume}
              onMasterVolumeChange={setMasterVolume}
              filterValue={filterValue}
              onFilterChange={setFilterValue}
              onExportWav={handleExportWav}
              isExporting={isExporting}
              activePattern={activePattern}
              onSelectPattern={setActivePattern}
              loopMode={loopMode}
              onToggleLoop={() => setLoopMode(prev => !prev)}
            />

            {/* Main Multi-Track Sequencer Grid */}
            <SequencerGrid
              tracks={tracks}
              samples={currentPack.samples}
              currentStep={currentStep}
              isPlaying={isPlaying}
              onToggleStep={handleToggleStep}
              onUpdateTrack={handleUpdateTrack}
              onAuditionSample={handleAuditionSample}
              onClearTrack={handleClearTrack}
              stepCount={STEP_COUNT}
            />

            {/* Live MPC Drum Pads */}
            <DrumPads
              samples={currentPack.samples}
              tracks={tracks}
              onTriggerSample={(sampleId) => {
                // Flash pad
              }}
              activePlayStep={currentStep}
            />

            {/* Channel Mixer & Pan Faders */}
            <TrackMixerRow
              tracks={tracks}
              samples={currentPack.samples}
              onUpdateTrack={handleUpdateTrack}
            />
          </div>
        )}

        {/* VIEW 2: WEEKLY CHARTS & LEADERBOARD */}
        {activeTab === 'charts' && (
          <WeeklyCharts
            beats={communityBeats}
            currentPack={currentPack}
            playingBeatId={playingCommunityBeatId}
            onTogglePlayBeat={handleTogglePlayCommunityBeat}
            onVote={handleVote}
            onHype={handleHype}
            onRemix={handleRemixBeat}
            onGoToStudio={() => setActiveTab('studio')}
          />
        )}

        {/* VIEW 3: BLIND BEAT BATTLE ARENA */}
        {activeTab === 'battle' && (
          <BlindBattle
            beats={communityBeats}
            playingBeatId={playingCommunityBeatId}
            onTogglePlayBeat={handleTogglePlayCommunityBeat}
            onVote={handleVote}
            onRemix={handleRemixBeat}
          />
        )}

        {/* VIEW 4: SAMPLE PACKS & CONSTRAINTS */}
        {activeTab === 'packs' && (
          <SamplePacksView
            currentPackId={currentPack.id}
            onSelectPack={handleSelectPack}
            onGoToStudio={() => setActiveTab('studio')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800 bg-neutral-950 py-6 px-4 lg:px-8 mt-12 text-center text-xs text-neutral-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-white">Beat Builder</span>
            <span>·</span>
            <span>30-Second Pack Battles & Weekly Producer Charts</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-mono text-neutral-400">
            <span>Web Audio 44.1kHz DAW</span>
            <span>·</span>
            <span>Uncompressed 16-Bit WAV Export</span>
          </div>
        </div>
      </footer>

      {/* Submission Modal */}
      <SubmitBeatModal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        tracks={tracks}
        bpm={bpm}
        swing={swing}
        currentPack={currentPack}
        computedDurationSec={computedDurationSec}
        onSubmitSuccess={handleSubmissionSuccess}
      />
    </div>
  );
}
