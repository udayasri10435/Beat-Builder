import React from 'react';
import { ActiveTab } from '../types/beat';
import { Play, Flame, Trophy, Disc3, Plus, Upload } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onNewBeat: () => void;
  onSubmitClick: () => void;
  weekNumber: number;
  packTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onNewBeat,
  onSubmitClick,
  weekNumber,
  packTitle
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800 bg-neutral-950/95 backdrop-blur px-4 lg:px-8 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Disc3 className="w-5 h-5 animate-spin-slow" />
          </div>
          <button
            onClick={() => setActiveTab('studio')}
            className="text-left group"
          >
            <span className="font-display font-bold text-lg lg:text-xl tracking-tight text-white group-hover:text-amber-400 transition-colors">
              Beat Builder
            </span>
          </button>
        </div>

        {/* Zone 2: 4 Clean Navigation Links */}
        <nav className="flex items-center gap-1 sm:gap-2 bg-neutral-900/90 border border-neutral-800 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('studio')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'studio'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
            }`}
          >
            <Play className="w-3.5 h-3.5 text-amber-400" />
            <span>Studio DAW</span>
          </button>

          <button
            onClick={() => setActiveTab('charts')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'charts'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span>Weekly Charts</span>
          </button>

          <button
            onClick={() => setActiveTab('battle')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'battle'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-rose-500" />
            <span>Blind Battle</span>
          </button>

          <button
            onClick={() => setActiveTab('packs')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'packs'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
            }`}
          >
            <Disc3 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Packs</span>
          </button>
        </nav>

        {/* Zone 3: 1-2 Primary Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onNewBeat}
            title="Reset to clean sequencer"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-neutral-300 bg-neutral-900 border border-neutral-700/80 rounded-lg hover:bg-neutral-800 hover:text-white transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Beat</span>
          </button>

          <button
            onClick={onSubmitClick}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 active:scale-95 rounded-lg shadow-sm transition-all whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Submit Track</span>
          </button>
        </div>
      </div>
    </header>
  );
};
