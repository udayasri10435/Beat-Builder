import React, { useState, useRef } from 'react';
import { Play, Pause, Square, Download, Sliders, Volume2, RotateCcw, Clock } from 'lucide-react';
import { AudioVisualizer } from './AudioVisualizer';

interface TransportBarProps {
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStop: () => void;
  bpm: number;
  onBpmChange: (bpm: number) => void;
  swing: number;
  onSwingChange: (swing: number) => void;
  currentStep: number;
  totalSteps: number;
  currentTimeSec: number;
  targetMaxSeconds: number; // 30.0s limit
  masterVolume: number;
  onMasterVolumeChange: (vol: number) => void;
  filterValue: number;
  onFilterChange: (val: number) => void;
  onExportWav: () => void;
  isExporting: boolean;
  activePattern: number; // 0, 1, etc.
  onSelectPattern: (p: number) => void;
  loopMode: boolean;
  onToggleLoop: () => void;
}

export const TransportBar: React.FC<TransportBarProps> = ({
  isPlaying,
  onTogglePlay,
  onStop,
  bpm,
  onBpmChange,
  swing,
  onSwingChange,
  currentStep,
  totalSteps,
  currentTimeSec,
  targetMaxSeconds,
  masterVolume,
  onMasterVolumeChange,
  filterValue,
  onFilterChange,
  onExportWav,
  isExporting,
  activePattern,
  onSelectPattern,
  loopMode,
  onToggleLoop
}) => {
  // Tap Tempo state
  const tapTimesRef = useRef<number[]>([]);
  const [tapActive, setTapActive] = useState(false);

  const handleTapTempo = () => {
    const now = performance.now();
    const tapTimes = tapTimesRef.current;
    tapTimes.push(now);
    setTapActive(true);
    setTimeout(() => setTapActive(false), 150);

    // Keep only taps within last 2.5 seconds
    const recent = tapTimes.filter(t => now - t < 2500);
    tapTimesRef.current = recent;

    if (recent.length >= 3) {
      const intervals = [];
      for (let i = 1; i < recent.length; i++) {
        intervals.push(recent[i] - recent[i - 1]);
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const computedBpm = Math.round(60000 / avgInterval);
      if (computedBpm >= 60 && computedBpm <= 180) {
        onBpmChange(computedBpm);
      }
    }
  };

  const progressPercent = Math.min(100, (currentTimeSec / targetMaxSeconds) * 100);
  const isNearLimit = currentTimeSec >= targetMaxSeconds - 1.5;

  return (
    <div className="w-full bg-neutral-900/90 border border-neutral-800 rounded-2xl p-3 sm:p-4 shadow-xl">
      <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
        {/* Left Section: Playback Controls & 30s Official Meter */}
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Main Play Button */}
          <button
            onClick={onTogglePlay}
            className={`flex items-center justify-center w-12 h-12 rounded-xl text-neutral-950 font-bold shadow-md transition-all active:scale-95 ${
              isPlaying
                ? 'bg-amber-400 hover:bg-amber-300 ring-2 ring-amber-400/50'
                : 'bg-white hover:bg-neutral-200'
            }`}
            title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current ml-0.5" />
            )}
          </button>

          {/* Stop Button */}
          <button
            onClick={onStop}
            className="flex items-center justify-center w-10 h-10 rounded-xl bg-neutral-800 text-neutral-300 hover:bg-neutral-700 hover:text-white transition-colors"
            title="Stop & Reset to Start"
          >
            <Square className="w-4 h-4 fill-current" />
          </button>

          {/* Loop Mode */}
          <button
            onClick={onToggleLoop}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-all ${
              loopMode
                ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                : 'bg-neutral-800/80 border-neutral-700/60 text-neutral-400 hover:text-neutral-200'
            }`}
            title="Loop 30-Second Beat"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${loopMode ? 'text-amber-400' : ''}`} />
            <span>Loop</span>
          </button>

          {/* Pattern Switcher (A / B) */}
          <div className="flex items-center bg-neutral-950/80 border border-neutral-800 rounded-lg p-0.5">
            <button
              onClick={() => onSelectPattern(0)}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-all ${
                activePattern === 0
                  ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Pattern A
            </button>
            <button
              onClick={() => onSelectPattern(1)}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-all ${
                activePattern === 1
                  ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Pattern B
            </button>
          </div>

          {/* 30-Second Challenge Clock */}
          <div className="flex items-center gap-3 bg-neutral-950/90 border border-neutral-800 rounded-xl px-3.5 py-2">
            <Clock className={`w-4 h-4 ${isNearLimit ? 'text-rose-400 animate-pulse' : 'text-amber-400'}`} />
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1 text-xs">
                <span className="font-mono text-sm font-bold text-white tabular-nums">
                  {currentTimeSec.toFixed(1)}s
                </span>
                <span className="text-neutral-500 font-mono text-[11px]">/ 30.0s MAX</span>
              </div>
              {/* Mini visual progress track */}
              <div className="w-24 h-1.5 bg-neutral-800 rounded-full overflow-hidden mt-1">
                <div
                  className={`h-full transition-all duration-100 ${
                    isNearLimit ? 'bg-rose-500' : 'bg-gradient-to-r from-amber-400 to-amber-500'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Center: Live Audio Visualizer Spectrum */}
        <div className="w-full lg:w-64 xl:w-72 hidden md:block">
          <AudioVisualizer isPlaying={isPlaying} height={44} />
        </div>

        {/* Right Section: BPM, Swing, Filter & Export */}
        <div className="flex flex-wrap items-center justify-end gap-3 w-full lg:w-auto">
          {/* BPM Control */}
          <div className="flex items-center gap-2 bg-neutral-950/80 border border-neutral-800 rounded-xl px-3 py-1.5">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-400">TEMPO</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="60"
                  max="180"
                  value={bpm}
                  onChange={(e) => onBpmChange(Number(e.target.value) || 85)}
                  className="w-12 bg-transparent text-sm font-mono font-bold text-amber-300 focus:outline-none tabular-nums"
                />
                <span className="text-[10px] font-mono text-neutral-500">BPM</span>
              </div>
            </div>
            <button
              onClick={handleTapTempo}
              className={`px-2 py-1 text-[11px] font-mono font-bold uppercase rounded border transition-colors ${
                tapActive
                  ? 'bg-amber-400 text-neutral-950 border-amber-300'
                  : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:text-white'
              }`}
              title="Click in rhythm to set BPM"
            >
              TAP
            </button>
          </div>

          {/* Swing Control */}
          <div className="hidden sm:flex flex-col bg-neutral-950/80 border border-neutral-800 rounded-xl px-3 py-1.5 w-28">
            <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400">
              <span>SWING</span>
              <span className="text-amber-400 font-bold tabular-nums">{swing}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              value={swing}
              onChange={(e) => onSwingChange(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-neutral-800 rounded-lg mt-1"
            />
          </div>

          {/* DJ Filter Sweep (LPF / Flat / HPF) */}
          <div className="hidden sm:flex flex-col bg-neutral-950/80 border border-neutral-800 rounded-xl px-3 py-1.5 w-32">
            <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400">
              <span className="flex items-center gap-1">
                <Sliders className="w-2.5 h-2.5 text-neutral-400" />
                FILTER
              </span>
              <span className="text-amber-400 font-bold tabular-nums">
                {filterValue === 0 ? 'FLAT' : filterValue < 0 ? `LP ${filterValue}` : `HP +${filterValue}`}
              </span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={filterValue}
              onChange={(e) => onFilterChange(Number(e.target.value))}
              onDoubleClick={() => onFilterChange(0)}
              title="Double-click to reset filter"
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-neutral-800 rounded-lg mt-1"
            />
          </div>

          {/* Master Volume */}
          <div className="hidden xl:flex flex-col bg-neutral-950/80 border border-neutral-800 rounded-xl px-3 py-1.5 w-28">
            <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400">
              <span className="flex items-center gap-1">
                <Volume2 className="w-2.5 h-2.5 text-neutral-400" />
                VOL
              </span>
              <span className="text-amber-400 font-bold tabular-nums">{Math.round(masterVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={masterVolume}
              onChange={(e) => onMasterVolumeChange(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-neutral-800 rounded-lg mt-1"
            />
          </div>

          {/* Export WAV Master Button */}
          <button
            onClick={onExportWav}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-200 bg-neutral-800 hover:bg-neutral-700 active:scale-95 border border-neutral-700 rounded-xl transition-all whitespace-nowrap disabled:opacity-50"
            title="Download uncompressed 30-second studio WAV"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>{isExporting ? 'Exporting...' : 'Export WAV'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
