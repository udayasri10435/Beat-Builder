import React, { useState } from 'react';
import { SamplePack, SampleDefinition } from '../types/beat';
import { SAMPLE_PACKS } from '../data/samplePacks';
import { soundEngine } from '../audio/soundEngine';
import { Disc3, Play, CheckCircle2, Clock, Sparkles, ArrowRight, ShieldAlert } from 'lucide-react';

interface SamplePacksViewProps {
  currentPackId: string;
  onSelectPack: (pack: SamplePack) => void;
  onGoToStudio: () => void;
}

export const SamplePacksView: React.FC<SamplePacksViewProps> = ({
  currentPackId,
  onSelectPack,
  onGoToStudio
}) => {
  const [selectedPack, setSelectedPack] = useState<SamplePack>(
    SAMPLE_PACKS.find(p => p.id === currentPackId) || SAMPLE_PACKS[0]
  );
  const [auditioningId, setAuditioningId] = useState<string | null>(null);

  const handleAuditionSample = (sample: SampleDefinition) => {
    soundEngine.playSample(sample, 0, 85, 0);
    setAuditioningId(sample.id);
    setTimeout(() => setAuditioningId(prev => (prev === sample.id ? null : prev)), 200);
  };

  const isCurrentActive = selectedPack.id === currentPackId;

  return (
    <div className="w-full max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="space-y-1">
        <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-white">
          Weekly Sample Packs
        </h2>
        <p className="text-sm text-neutral-400">
          Every Monday, a fresh sonic constraint drops. Everyone builds from the exact same pack.
        </p>
      </div>

      {/* Pack Selection Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {SAMPLE_PACKS.map(pack => {
          const isSelected = selectedPack.id === pack.id;
          const isCurrentChallenge = pack.weekNumber === 39;

          return (
            <button
              key={pack.id}
              onClick={() => setSelectedPack(pack)}
              className={`p-5 rounded-2xl border text-left transition-all relative overflow-hidden group ${
                isSelected
                  ? 'bg-neutral-900 border-amber-500 ring-1 ring-amber-500/40 shadow-xl'
                  : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/80'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-amber-400">
                  WEEK {pack.weekNumber}
                </span>
                {isCurrentChallenge ? (
                  <span className="text-[11px] font-mono text-emerald-400 font-semibold">
                    ACTIVE CHALLENGE
                  </span>
                ) : (
                  <span className="text-[11px] font-mono text-neutral-500">
                    ARCHIVED
                  </span>
                )}
              </div>

              <h3 className="text-lg font-bold text-white mt-2 group-hover:text-amber-300 transition-colors">
                {pack.title}
              </h3>

              <p className="text-xs text-neutral-400 mt-1 line-clamp-2">
                {pack.subtitle}
              </p>

              <div className="flex items-center gap-2 text-[11px] text-neutral-400 mt-4">
                <span>{pack.genre}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{pack.bpmDefault} BPM</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Pack Deep Dive & Sound Audition Rack */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-neutral-800">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
              <Disc3 className="w-4 h-4" />
              <span>PACK INVENTORY · {selectedPack.samples.length} CURATED SOUNDS</span>
            </div>
            <h3 className="text-2xl font-display font-bold text-white">
              {selectedPack.title}
            </h3>
            <p className="text-sm text-neutral-400 max-w-xl">
              {selectedPack.description}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                onSelectPack(selectedPack);
                onGoToStudio();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs shadow-md transition-all active:scale-95"
            >
              <span>Load Pack Into Studio</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 8-Sample Audition Rack */}
        <div>
          <h4 className="text-xs font-mono uppercase tracking-wider text-neutral-400 mb-3">
            Sample Audition Rack (Click any sound to listen)
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {selectedPack.samples.map(sample => {
              const isPlaying = auditioningId === sample.id;

              return (
                <button
                  key={sample.id}
                  onClick={() => handleAuditionSample(sample)}
                  className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between group active:scale-95 ${
                    isPlaying
                      ? 'bg-amber-500/20 border-amber-400 shadow-md'
                      : 'bg-neutral-950/80 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border border-neutral-700/60 text-white"
                      style={{ backgroundColor: `${sample.color}25` }}
                    >
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    </div>

                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">
                        {sample.name}
                      </p>
                      <p className="text-[10px] text-neutral-400 capitalize">
                        {sample.category} · Key [{sample.keyTrigger}]
                      </p>
                    </div>
                  </div>

                  <span
                    className="w-2 h-2 rounded-full shrink-0 ml-2"
                    style={{ backgroundColor: sample.color }}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* Official Rules Box */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono text-neutral-300">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>OFFICIAL COMPETITION CONSTRAINTS</span>
          </div>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-neutral-400 pt-1">
            {selectedPack.rules.map((rule, idx) => (
              <li key={idx} className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{rule}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
