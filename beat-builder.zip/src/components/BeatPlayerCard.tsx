import React from 'react';
import { CommunityBeat } from '../types/beat';
import { Play, Pause, Flame, Heart, Share2, Sparkles, ExternalLink, ArrowUp, ArrowDown, Minus } from 'lucide-react';

interface BeatPlayerCardProps {
  beat: CommunityBeat;
  isPlayingThisBeat: boolean;
  onTogglePlay: (beat: CommunityBeat) => void;
  onVote: (beatId: string) => void;
  onHype: (beatId: string) => void;
  onRemix: (beat: CommunityBeat) => void;
}

export const BeatPlayerCard: React.FC<BeatPlayerCardProps> = ({
  beat,
  isPlayingThisBeat,
  onTogglePlay,
  onVote,
  onHype,
  onRemix
}) => {
  const getRankBadge = (rank: number) => {
    if (rank === 1) return { bg: 'bg-amber-400 text-neutral-950 font-extrabold', border: 'border-amber-400/50' };
    if (rank === 2) return { bg: 'bg-neutral-200 text-neutral-900 font-bold', border: 'border-neutral-300' };
    if (rank === 3) return { bg: 'bg-amber-700/60 text-amber-200 font-bold', border: 'border-amber-700/80' };
    return { bg: 'bg-neutral-800 text-neutral-400 font-mono', border: 'border-neutral-700/60' };
  };

  const rankStyle = getRankBadge(beat.rank);

  return (
    <div
      className={`group relative flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 rounded-2xl border transition-all ${
        isPlayingThisBeat
          ? 'bg-neutral-900/90 border-amber-500/50 shadow-[0_0_25px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/30'
          : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/80'
      }`}
    >
      {/* Left: Rank, Play Button, Track Title & Producer */}
      <div className="flex items-center gap-3.5 min-w-0 w-full md:w-auto">
        {/* Rank Number & Momentum */}
        <div className="flex flex-col items-center justify-center w-9 shrink-0">
          <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs border ${rankStyle.bg} ${rankStyle.border}`}>
            #{beat.rank}
          </span>
          {/* Momentum Indicator */}
          <div className="flex items-center text-[10px] font-mono mt-1">
            {beat.rankDelta === 999 ? (
              <span className="text-emerald-400 font-bold">NEW</span>
            ) : beat.rankDelta > 0 ? (
              <span className="text-emerald-400 flex items-center font-bold">
                <ArrowUp className="w-2.5 h-2.5" />
                {beat.rankDelta}
              </span>
            ) : beat.rankDelta < 0 ? (
              <span className="text-rose-400 flex items-center">
                <ArrowDown className="w-2.5 h-2.5" />
                {Math.abs(beat.rankDelta)}
              </span>
            ) : (
              <span className="text-neutral-500 flex items-center">
                <Minus className="w-2.5 h-2.5" />
              </span>
            )}
          </div>
        </div>

        {/* Play / Pause Audition Button */}
        <button
          onClick={() => onTogglePlay(beat)}
          className={`w-11 h-11 shrink-0 rounded-xl flex items-center justify-center transition-all active:scale-95 shadow-md ${
            isPlayingThisBeat
              ? 'bg-amber-400 text-neutral-950 font-bold ring-2 ring-amber-400/50'
              : 'bg-neutral-800 text-neutral-200 hover:bg-amber-400 hover:text-neutral-950'
          }`}
          title={isPlayingThisBeat ? 'Pause' : 'Play Beat (30s)'}
        >
          {isPlayingThisBeat ? (
            <Pause className="w-5 h-5 fill-current" />
          ) : (
            <Play className="w-5 h-5 fill-current ml-0.5" />
          )}
        </button>

        {/* Track Title, Producer Handle, Metadata */}
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-semibold text-white truncate group-hover:text-amber-300 transition-colors">
              {beat.title}
            </h4>
          </div>

          <div className="flex items-center gap-2 text-xs text-neutral-400 mt-0.5">
            <span className="font-medium text-neutral-300">{beat.producer}</span>
            <span className="text-neutral-500 font-mono text-[11px]">{beat.producerHandle}</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="font-mono text-neutral-400 tabular-nums">{beat.bpm} BPM</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="font-mono text-amber-400/90 tabular-nums">{beat.durationSeconds}s</span>
          </div>

          {/* Badges as clean unboxed text with subtle typographic separators */}
          {beat.badges.length > 0 && (
            <div className="flex items-center gap-2 text-[11px] text-amber-400/80 mt-1">
              {beat.badges.map((badge, idx) => (
                <React.Fragment key={badge}>
                  <span>{badge}</span>
                  {idx < beat.badges.length - 1 && <span aria-hidden="true" className="text-neutral-600">·</span>}
                </React.Fragment>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right: Voting Buttons, Hype, Remix In Studio */}
      <div className="flex items-center justify-between md:justify-end gap-2.5 w-full md:w-auto pt-2 md:pt-0 border-t md:border-t-0 border-neutral-800">
        {/* Upvote Button */}
        <button
          onClick={() => onVote(beat.id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all active:scale-95 ${
            beat.hasVoted
              ? 'bg-rose-500/15 border-rose-500/50 text-rose-400'
              : 'bg-neutral-800/80 border-neutral-700/60 text-neutral-300 hover:border-rose-500/40 hover:text-white'
          }`}
          title="Vote for this beat"
        >
          <Heart className={`w-3.5 h-3.5 ${beat.hasVoted ? 'fill-current text-rose-500' : ''}`} />
          <span className="tabular-nums font-mono">{beat.votes}</span>
        </button>

        {/* Hype Fire Button */}
        <button
          onClick={() => onHype(beat.id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all active:scale-95 ${
            beat.hasHyped
              ? 'bg-amber-500/15 border-amber-500/50 text-amber-400'
              : 'bg-neutral-800/80 border-neutral-700/60 text-neutral-300 hover:border-amber-500/40 hover:text-white'
          }`}
          title="Send Hype"
        >
          <Flame className={`w-3.5 h-3.5 ${beat.hasHyped ? 'fill-current text-amber-500' : ''}`} />
          <span className="tabular-nums font-mono">{beat.hypeCount}</span>
        </button>

        {/* Remix / Open in DAW */}
        <button
          onClick={() => onRemix(beat)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white border border-neutral-700 text-xs font-medium transition-colors whitespace-nowrap"
          title="Load this beat into the studio sequencer to remix it"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Remix in DAW</span>
        </button>
      </div>
    </div>
  );
};
