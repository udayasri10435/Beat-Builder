import React, { useState, useEffect, useCallback } from 'react';
import { SampleDefinition, TrackData } from '../types/beat';
import { soundEngine } from '../audio/soundEngine';
import { Music2 } from 'lucide-react';

interface DrumPadsProps {
  samples: SampleDefinition[];
  tracks: TrackData[];
  onTriggerSample: (sampleId: string) => void;
  activePlayStep: number;
}

export const DrumPads: React.FC<DrumPadsProps> = ({
  samples,
  tracks,
  onTriggerSample,
  activePlayStep
}) => {
  const [activePad, setActivePad] = useState<string | null>(null);

  const triggerPad = useCallback((sample: SampleDefinition) => {
    const track = tracks.find(t => t.sampleId === sample.id);
    const vol = track ? track.volume : 80;
    const pan = track ? track.pan : 0;
    const pitch = track ? track.pitch : 0;

    soundEngine.playSample(sample, pitch, vol, pan);
    onTriggerSample(sample.id);
    setActivePad(sample.id);
    setTimeout(() => {
      setActivePad(prev => (prev === sample.id ? null : prev));
    }, 120);
  }, [tracks, onTriggerSample]);

  // Keyboard shortcut listener for 1-8
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }
      const match = samples.find(s => s.keyTrigger === e.key);
      if (match) {
        e.preventDefault();
        triggerPad(match);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [samples, triggerPad]);

  return (
    <div className="w-full bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-3.5 sm:p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Music2 className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
            Live MPC Drum Pads
          </h3>
        </div>
        <span className="text-[11px] font-mono text-neutral-500 hidden sm:inline">
          Trigger with Keys [1] – [8]
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
        {samples.map((sample, idx) => {
          const track = tracks.find(t => t.sampleId === sample.id);
          const isFired = activePad === sample.id;
          const isStepActive = track && track.steps[activePlayStep % track.steps.length];

          return (
            <button
              key={sample.id}
              onClick={() => triggerPad(sample)}
              className={`relative flex flex-col justify-between p-3 h-24 rounded-xl border text-left transition-all select-none active:scale-95 group ${
                isFired
                  ? 'border-white bg-amber-500/30 shadow-[0_0_20px_rgba(245,158,11,0.4)] translate-y-0.5'
                  : isStepActive
                  ? 'border-amber-500/40 bg-neutral-800/90'
                  : 'border-neutral-800 bg-neutral-950/70 hover:border-neutral-700 hover:bg-neutral-800/50'
              }`}
            >
              {/* Header: Key & Dot */}
              <div className="flex items-center justify-between w-full">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: sample.color }}
                />
                <span className="font-mono text-[11px] font-bold text-neutral-400 group-hover:text-amber-400 border border-neutral-800 px-1.5 py-0.5 rounded bg-neutral-900">
                  {sample.keyTrigger}
                </span>
              </div>

              {/* Sample Name & Details */}
              <div className="mt-auto">
                <p className="text-xs font-semibold text-white truncate">
                  {sample.name}
                </p>
                <div className="flex items-center justify-between text-[10px] text-neutral-400 mt-0.5">
                  <span className="capitalize">{sample.category}</span>
                  {track && track.pitch !== 0 && (
                    <span className="font-mono text-amber-400">
                      {track.pitch > 0 ? `+${track.pitch}` : track.pitch}st
                    </span>
                  )}
                </div>
              </div>

              {/* Bottom active accent bar */}
              <div
                className={`absolute bottom-0 left-0 right-0 h-1 rounded-b-xl transition-opacity ${
                  isFired ? 'opacity-100' : 'opacity-20'
                }`}
                style={{ backgroundColor: sample.color }}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
};
