import React, { useEffect, useRef } from 'react';
import { soundEngine } from '../audio/soundEngine';

interface AudioVisualizerProps {
  isPlaying: boolean;
  className?: string;
  height?: number;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isPlaying,
  className = '',
  height = 54
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const analyser = soundEngine.getAnalyser();
      const width = canvas.width;
      const h = canvas.height;

      ctx.clearRect(0, 0, width, h);

      if (!analyser || !isPlaying) {
        // Subtle idle line
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.2)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        const midY = h / 2;
        ctx.moveTo(0, midY);
        for (let x = 0; x < width; x += 4) {
          const idleWave = Math.sin((x + performance.now() * 0.05) * 0.05) * 1.5;
          ctx.lineTo(x, midY + idleWave);
        }
        ctx.stroke();

        animId = requestAnimationFrame(render);
        return;
      }

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      analyser.getByteFrequencyData(dataArray);

      // Render frequency bars
      const barCount = 48;
      const barWidth = (width / barCount) * 0.7;
      const gap = (width / barCount) * 0.3;

      for (let i = 0; i < barCount; i++) {
        // logarithmic frequency sampling
        const dataIndex = Math.min(
          bufferLength - 1,
          Math.floor(Math.pow(i / barCount, 1.4) * (bufferLength / 2))
        );
        const value = dataArray[dataIndex] || 0;
        const percent = value / 255;
        const barHeight = Math.max(3, percent * (h - 4));
        const x = i * (barWidth + gap);
        const y = h - barHeight;

        // Gradient from amber to rose
        const grad = ctx.createLinearGradient(0, y, 0, h);
        grad.addColorStop(0, '#f59e0b');
        grad.addColorStop(0.6, '#ec4899');
        grad.addColorStop(1, '#6366f1');

        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, barHeight);

        // Peak cap
        ctx.fillStyle = '#fef08a';
        ctx.fillRect(x, Math.max(1, y - 2), barWidth, 1.5);
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isPlaying]);

  return (
    <div className={`relative overflow-hidden rounded-lg bg-neutral-950/80 border border-neutral-800/80 p-2 ${className}`}>
      <canvas
        ref={canvasRef}
        width={380}
        height={height}
        className="w-full h-full block"
      />
    </div>
  );
};
