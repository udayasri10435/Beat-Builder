import React from 'react';
import { TrackData, SampleDefinition } from '../types/beat';
import { SlidersHorizontal, Volume2 } from 'lucide-react';

interface TrackMixerRowProps {
  tracks: TrackData[];
  samples: SampleDefinition[];
  onUpdateTrack: (trackId: string, updates: Partial<TrackData>) => void;
}

export const TrackMixerRow: React.FC<TrackMixerRowProps> = ({
  tracks,
  samples,
  onUpdateTrack
}) => {
  const sampleMap = new Map<string, SampleDefinition>();
  samples.forEach(s => sampleMap.set(s.id, s));

  return (
    <div className="w-full bg-neutral-900/60 border border-neutral-800/80 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
            Channel Mixer & Level Faders
          </h3>
        </div>
        <span className="text-[11px] font-mono text-neutral-500">
          Stereo Panning & Balance
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {tracks.map(track => {
          const sample = sampleMap.get(track.sampleId);
          if (!sample) return null;

          return (
            <div
              key={track.id}
              className="bg-neutral-950/80 border border-neutral-800/90 rounded-xl p-3 flex flex-col items-center justify-between gap-2 text-center"
            >
              {/* Track Name */}
              <div className="w-full truncate">
                <span className="text-xs font-medium text-white truncate block">
                  {track.name}
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  CH {sample.keyTrigger}
                </span>
              </div>

              {/* Volume Slider (Vertical style simulated or clean slider) */}
              <div className="flex flex-col items-center gap-1 w-full my-1">
                <div className="flex justify-between w-full text-[10px] font-mono text-neutral-400">
                  <span>VOL</span>
                  <span className="text-amber-400 tabular-nums">{track.volume}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={track.volume}
                  onChange={(e) => onUpdateTrack(track.id, { volume: Number(e.target.value) })}
                  className="w-full accent-amber-400 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
                />
              </div>

              {/* Pan Slider */}
              <div className="flex flex-col items-center gap-1 w-full">
                <div className="flex justify-between w-full text-[10px] font-mono text-neutral-400">
                  <span>PAN</span>
                  <span className="text-neutral-300 tabular-nums">
                    {track.pan === 0 ? 'C' : track.pan < 0 ? `L${Math.abs(track.pan)}` : `R${track.pan}`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-50"
                  max="50"
                  value={track.pan}
                  onChange={(e) => onUpdateTrack(track.id, { pan: Number(e.target.value) })}
                  onDoubleClick={() => onUpdateTrack(track.id, { pan: 0 })}
                  className="w-full accent-neutral-400 cursor-pointer h-1 bg-neutral-800 rounded-lg"
                  title="Double-click to center pan"
                />
              </div>

              {/* Color Accent Indicator */}
              <div
                className="w-full h-1 rounded-full mt-1"
                style={{ backgroundColor: sample.color }}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
