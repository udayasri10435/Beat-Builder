import React, { useState } from 'react';
import { CommunityBeat } from '../types/beat';
import { Flame, Play, Pause, Sparkles, Trophy, ArrowRight, RotateCw, Volume2, ShieldCheck } from 'lucide-react';

interface BlindBattleProps {
  beats: CommunityBeat[];
  playingBeatId: string | null;
  onTogglePlayBeat: (beat: CommunityBeat) => void;
  onVote: (beatId: string) => void;
  onRemix: (beat: CommunityBeat) => void;
}

export const BlindBattle: React.FC<BlindBattleProps> = ({
  beats,
  playingBeatId,
  onTogglePlayBeat,
  onVote,
  onRemix
}) => {
  const [matchupIndex, setMatchupIndex] = useState(0);
  const [hasVotedCurrent, setHasVotedCurrent] = useState(false);
  const [votedChoice, setVotedChoice] = useState<'A' | 'B' | null>(null);

  // Pick two distinct beats for current matchup
  const beatA = beats[matchupIndex % beats.length];
  const beatB = beats[(matchupIndex + 1) % beats.length];

  const handleVote = (choice: 'A' | 'B') => {
    if (hasVotedCurrent) return;
    const winner = choice === 'A' ? beatA : beatB;
    onVote(winner.id);
    setVotedChoice(choice);
    setHasVotedCurrent(true);
  };

  const handleNextMatchup = () => {
    setMatchupIndex(prev => prev + 2);
    setHasVotedCurrent(false);
    setVotedChoice(null);
  };

  if (!beatA || !beatB) {
    return (
      <div className="text-center py-12 text-neutral-400">
        Loading battle contestants...
      </div>
    );
  }

  const isPlayingA = playingBeatId === beatA.id;
  const isPlayingB = playingBeatId === beatB.id;

  // Compute vote percentage after voting
  const totalVotes = (beatA.votes || 1) + (beatB.votes || 1);
  const percentA = Math.round((beatA.votes / totalVotes) * 100);
  const percentB = 100 - percentA;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Banner */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-mono">
          <Flame className="w-3.5 h-3.5" />
          <span>BLIND ARENA · PRODUCER UNBIASED VOTING</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-white">
          Blind Beat Battle
        </h2>
        <p className="text-sm text-neutral-400 max-w-md mx-auto">
          Both tracks were crafted exclusively with this week's Tokyo Rain pack. Listen closely and vote for the superior groove.
        </p>
      </div>

      {/* Versus Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative">
        {/* VS badge in center */}
        <div className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-neutral-900 border-2 border-neutral-700 items-center justify-center font-display font-extrabold text-amber-400 shadow-xl">
          VS
        </div>

        {/* BEAT ALPHA */}
        <div
          className={`flex flex-col justify-between p-6 rounded-3xl border transition-all ${
            isPlayingA
              ? 'bg-neutral-900/90 border-amber-500 ring-2 ring-amber-500/30 shadow-2xl'
              : 'bg-neutral-900/50 border-neutral-800'
          }`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold tracking-wider text-amber-400">
                BEAT ALPHA
              </span>
              <span className="text-xs font-mono text-neutral-400 tabular-nums">
                {beatA.bpm} BPM · {beatA.durationSeconds}s
              </span>
            </div>

            {/* Play Button & Wave */}
            <div className="flex items-center gap-4 py-3">
              <button
                onClick={() => onTogglePlayBeat(beatA)}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all active:scale-95 shadow-md ${
                  isPlayingA
                    ? 'bg-amber-400 text-neutral-950 font-bold ring-4 ring-amber-400/40'
                    : 'bg-neutral-800 text-neutral-100 hover:bg-neutral-700'
                }`}
                title="Audition Beat Alpha"
              >
                {isPlayingA ? (
                  <Pause className="w-6 h-6 fill-current" />
                ) : (
                  <Play className="w-6 h-6 fill-current ml-0.5" />
                )}
              </button>

              <div className="flex-1">
                {!hasVotedCurrent ? (
                  <div className="space-y-1">
                    <p className="text-base font-semibold text-white">
                      Anonymous Contestant #1
                    </p>
                    <p className="text-xs text-neutral-500 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
                      Producer identity hidden
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <p className="text-base font-semibold text-amber-400">
                      {beatA.title}
                    </p>
                    <p className="text-xs text-neutral-300">
                      by {beatA.producer} <span className="text-neutral-500 font-mono">({beatA.producerHandle})</span>
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Post-vote stats bar */}
            {hasVotedCurrent && (
              <div className="space-y-1.5 pt-2 border-t border-neutral-800">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-neutral-400">Community Score</span>
                  <span className="font-bold text-amber-400 tabular-nums">{percentA}% ({beatA.votes} votes)</span>
                </div>
                <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all duration-500"
                    style={{ width: `${percentA}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action / Vote Button */}
          <div className="pt-6">
            {!hasVotedCurrent ? (
              <button
                onClick={() => handleVote('A')}
                className="w-full py-3 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-sm shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <span>Vote Beat Alpha</span>
              </button>
            ) : (
              <button
                onClick={() => onRemix(beatA)}
                className="w-full py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Open & Remix in DAW</span>
              </button>
            )}
          </div>
        </div>

        {/* BEAT BETA */}
        <div
          className={`flex flex-col justify-between p-6 rounded-3xl border transition-all ${
            isPlayingB
              ? 'bg-neutral-900/90 border-cyan-500 ring-2 ring-cyan-500/30 shadow-2xl'
              : 'bg-neutral-900/50 border-neutral-800'
          }`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold tracking-wider text-cyan-400">
                BEAT BETA
              </span>
              <span className="text-xs font-mono text-neutral-400 tabular-nums">
                {beatB.bpm} BPM · {beatB.durationSeconds}s
              </span>
            </div>

            {/* Play Button & Wave */}
            <div className="flex items-center gap-4 py-3">
              <button
                onClick={() => onTogglePlayBeat(beatB)}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all active:scale-95 shadow-md ${
                  isPlayingB
                    ? 'bg-cyan-400 text-neutral-950 font-bold ring-4 ring-cyan-400/40'
                    : 'bg-neutral-800 text-neutral-100 hover:bg-neutral-700'
                }`}
                title="Audition Beat Beta"
              >
                {isPlayingB ? (
                  <Pause className="w-6 h-6 fill-current" />
                ) : (
                  <Play className="w-6 h-6 fill-current ml-0.5" />
                )}
              </button>

              <div className="flex-1">
                {!hasVotedCurrent ? (
                  <div className="space-y-1">
                    <p className="text-base font-semibold text-white">
                      Anonymous Contestant #2
                    </p>
                    <p className="text-xs text-neutral-500 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
                      Producer identity hidden
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <p className="text-base font-semibold text-cyan-400">
                      {beatB.title}
                    </p>
                    <p className="text-xs text-neutral-300">
                      by {beatB.producer} <span className="text-neutral-500 font-mono">({beatB.producerHandle})</span>
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Post-vote stats bar */}
            {hasVotedCurrent && (
              <div className="space-y-1.5 pt-2 border-t border-neutral-800">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-neutral-400">Community Score</span>
                  <span className="font-bold text-cyan-400 tabular-nums">{percentB}% ({beatB.votes} votes)</span>
                </div>
                <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 rounded-full transition-all duration-500"
                    style={{ width: `${percentB}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action / Vote Button */}
          <div className="pt-6">
            {!hasVotedCurrent ? (
              <button
                onClick={() => handleVote('B')}
                className="w-full py-3 px-4 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-neutral-950 font-bold text-sm shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <span>Vote Beat Beta</span>
              </button>
            ) : (
              <button
                onClick={() => onRemix(beatB)}
                className="w-full py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Open & Remix in DAW</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Next Matchup Action Bar */}
      {hasVotedCurrent && (
        <div className="flex items-center justify-center pt-4">
          <button
            onClick={handleNextMatchup}
            className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-white hover:bg-neutral-200 text-neutral-950 font-bold text-sm shadow-lg transition-all active:scale-95"
          >
            <span>Next Battle Matchup</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
