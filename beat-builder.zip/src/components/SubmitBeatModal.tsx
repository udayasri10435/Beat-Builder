import React, { useState } from 'react';
import { TrackData, SamplePack, CommunityBeat, BeatProject } from '../types/beat';
import { X, Upload, CheckCircle2, AlertCircle, Clock, Disc3 } from 'lucide-react';

interface SubmitBeatModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: TrackData[];
  bpm: number;
  swing: number;
  currentPack: SamplePack;
  computedDurationSec: number;
  onSubmitSuccess: (newBeat: CommunityBeat) => void;
}

export const SubmitBeatModal: React.FC<SubmitBeatModalProps> = ({
  isOpen,
  onClose,
  tracks,
  bpm,
  swing,
  currentPack,
  computedDurationSec,
  onSubmitSuccess
}) => {
  const [title, setTitle] = useState('');
  const [producer, setProducer] = useState('');
  const [handle, setHandle] = useState('');
  const [tag, setTag] = useState('Lo-Fi');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Validation rules
  const activeTracksCount = tracks.filter(t => t.steps.some(Boolean)).length;
  const isWithinDuration = computedDurationSec <= 30.1;
  const hasMinTracks = activeTracksCount >= 3;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!title.trim()) {
      setErrorMsg('Please give your beat a track title.');
      return;
    }
    if (!producer.trim()) {
      setErrorMsg('Please enter your producer or artist name.');
      return;
    }
    if (!hasMinTracks) {
      setErrorMsg(`Your beat must use at least 3 distinct sample tracks (currently using ${activeTracksCount}).`);
      return;
    }
    if (!isWithinDuration) {
      setErrorMsg('Beat exceeds the 30.0-second limit. Lower steps or increase BPM to fit within 30s.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const cleanHandle = handle.trim().startsWith('@')
        ? handle.trim()
        : `@${handle.trim() || producer.toLowerCase().replace(/\s+/g, '_')}`;

      const newProject: BeatProject = {
        id: `proj_${Date.now()}`,
        title: title.trim(),
        producer: producer.trim(),
        packId: currentPack.id,
        bpm,
        swing,
        stepCount: tracks[0]?.steps.length || 32,
        patternCount: 2,
        tracks: JSON.parse(JSON.stringify(tracks)),
        createdAt: Date.now(),
        tags: [tag, 'Week 39 Submission']
      };

      const newCommunityBeat: CommunityBeat = {
        id: `beat_${Date.now()}`,
        title: title.trim(),
        producer: producer.trim(),
        producerHandle: cleanHandle,
        avatarSeed: producer.trim(),
        packId: currentPack.id,
        weekNumber: currentPack.weekNumber,
        bpm,
        durationSeconds: Math.round(computedDurationSec * 10) / 10,
        votes: 1, // Author's first vote
        hypeCount: 1,
        rank: 99, // Will be placed dynamically
        rankDelta: 999, // NEW flag
        badges: ['Fresh Drop', 'New Submission'],
        submittedAt: new Date().toISOString(),
        project: newProject,
        hasVoted: true,
        hasHyped: true
      };

      setIsSubmitting(false);
      onSubmitSuccess(newCommunityBeat);
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                Submit Beat to Week {currentPack.weekNumber}
              </h3>
              <p className="text-xs text-neutral-400">
                Official chart entry · {currentPack.title}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Validation Checks Banner */}
        <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-neutral-400" />
              Duration Limit (&le; 30.0s)
            </span>
            <span
              className={`font-mono font-bold ${
                isWithinDuration ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {computedDurationSec.toFixed(1)}s / 30.0s {isWithinDuration ? '✓' : '✗ Over limit'}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-400 flex items-center gap-1.5">
              <Disc3 className="w-3.5 h-3.5 text-neutral-400" />
              Track Usage (&ge; 3 tracks)
            </span>
            <span
              className={`font-mono font-bold ${
                hasMinTracks ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {activeTracksCount} / 3 tracks {hasMinTracks ? '✓' : '✗ Need more tracks'}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Submission Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-neutral-300 uppercase mb-1.5">
              Track Title
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Shibuya Raindrop Groove"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono text-neutral-300 uppercase mb-1.5">
                Producer / Artist Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g. SoundWave"
                value={producer}
                onChange={(e) => setProducer(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-neutral-300 uppercase mb-1.5">
                Social / Producer Handle
              </label>
              <input
                type="text"
                placeholder="e.g. @soundwave"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-neutral-300 uppercase mb-1.5">
              Style / Sub-Genre Tag
            </label>
            <div className="flex flex-wrap gap-2">
              {['Lo-Fi Chill', 'Boom Bap', 'Downtempo', 'Jazzhop', 'Ambient Beat'].map(t => (
                <button
                  type="button"
                  key={t}
                  onClick={() => setTag(t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    tag === t
                      ? 'bg-amber-400 text-neutral-950 border-amber-400 font-bold'
                      : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting || !isWithinDuration || !hasMinTracks}
              className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-neutral-950 font-bold text-xs shadow-md transition-all active:scale-95 flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              <span>{isSubmitting ? 'Uploading to Charts...' : 'Submit to Leaderboard'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
