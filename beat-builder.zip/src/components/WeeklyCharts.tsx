import React, { useState } from 'react';
import { CommunityBeat, SamplePack } from '../types/beat';
import { BeatPlayerCard } from './BeatPlayerCard';
import { Trophy, Flame, Sparkles, Search, Clock, Disc3 } from 'lucide-react';

interface WeeklyChartsProps {
  beats: CommunityBeat[];
  currentPack: SamplePack;
  playingBeatId: string | null;
  onTogglePlayBeat: (beat: CommunityBeat) => void;
  onVote: (beatId: string) => void;
  onHype: (beatId: string) => void;
  onRemix: (beat: CommunityBeat) => void;
  onGoToStudio: () => void;
}

export const WeeklyCharts: React.FC<WeeklyChartsProps> = ({
  beats,
  currentPack,
  playingBeatId,
  onTogglePlayBeat,
  onVote,
  onHype,
  onRemix,
  onGoToStudio
}) => {
  const [filter, setFilter] = useState<'ranked' | 'hype' | 'fresh'>('ranked');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter and sort beats
  const filteredBeats = [...beats]
    .filter(b => {
      if (!searchQuery.trim()) return true;
      const query = searchQuery.toLowerCase();
      return (
        b.title.toLowerCase().includes(query) ||
        b.producer.toLowerCase().includes(query) ||
        b.producerHandle.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => {
      if (filter === 'ranked') return a.rank - b.rank;
      if (filter === 'hype') return b.hypeCount - a.hypeCount;
      if (filter === 'fresh') return new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime();
      return 0;
    });

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Weekly Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-neutral-800 bg-neutral-900/90 p-6 sm:p-8">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
              <Trophy className="w-4 h-4" />
              <span>WEEK {currentPack.weekNumber} OFFICIAL LEADERBOARD</span>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span className="text-neutral-400">{currentPack.title}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
              Weekly Producer Charts
            </h2>

            <p className="text-sm text-neutral-400 max-w-xl">
              Listen, vote, and see who crafted the most infectious 30-second beat from this week's exact same sample pack.
            </p>
          </div>

          {/* Voting Window Countdown */}
          <div className="flex flex-col items-start md:items-end bg-neutral-950/80 border border-neutral-800 p-4 rounded-2xl shrink-0">
            <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>CHART LOCKS IN</span>
            </div>
            <div className="text-xl sm:text-2xl font-mono font-bold text-white mt-1 tabular-nums">
              02d 14h 22m
            </div>
            <span className="text-[11px] text-neutral-500 mt-0.5">
              Sunday midnight PST
            </span>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Segmented control buttons */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl">
          <button
            onClick={() => setFilter('ranked')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              filter === 'ranked'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Top Ranked
          </button>
          <button
            onClick={() => setFilter('hype')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              filter === 'hype'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Most Hyped
          </button>
          <button
            onClick={() => setFilter('fresh')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              filter === 'fresh'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Fresh Drops
          </button>
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
          <input
            type="text"
            placeholder="Search beat or producer..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>
      </div>

      {/* Beats List */}
      <div className="space-y-3">
        {filteredBeats.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-neutral-800 rounded-2xl p-6">
            <Disc3 className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
            <p className="text-sm font-medium text-neutral-300">No beats found matching your search</p>
            <p className="text-xs text-neutral-500 mt-1">Try another keyword or submit your own track</p>
          </div>
        ) : (
          filteredBeats.map((beat) => (
            <BeatPlayerCard
              key={beat.id}
              beat={beat}
              isPlayingThisBeat={playingBeatId === beat.id}
              onTogglePlay={onTogglePlayBeat}
              onVote={onVote}
              onHype={onHype}
              onRemix={onRemix}
            />
          ))
        )}
      </div>

      {/* Call to action footer */}
      <div className="p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div>
          <h4 className="text-sm font-semibold text-white">Think you can craft a harder beat?</h4>
          <p className="text-xs text-neutral-400 mt-0.5">
            Grab the Week {currentPack.weekNumber} pack, build your 30-second loop in the DAW, and climb the charts.
          </p>
        </div>
        <button
          onClick={onGoToStudio}
          className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs rounded-xl shadow-sm transition-all whitespace-nowrap active:scale-95"
        >
          Open Studio DAW
        </button>
      </div>
    </div>
  );
};
