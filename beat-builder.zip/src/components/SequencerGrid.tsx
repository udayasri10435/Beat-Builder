import React from 'react';
import { TrackData, SampleDefinition } from '../types/beat';
import { Volume2, VolumeX, Play, SlidersHorizontal, RotateCcw } from 'lucide-react';

interface SequencerGridProps {
  tracks: TrackData[];
  samples: SampleDefinition[];
  currentStep: number;
  isPlaying: boolean;
  onToggleStep: (trackId: string, stepIndex: number) => void;
  onUpdateTrack: (trackId: string, updates: Partial<TrackData>) => void;
  onAuditionSample: (sample: SampleDefinition) => void;
  onClearTrack: (trackId: string) => void;
  stepCount: number; // 16 or 32
}

export const SequencerGrid: React.FC<SequencerGridProps> = ({
  tracks,
  samples,
  currentStep,
  isPlaying,
  onToggleStep,
  onUpdateTrack,
  onAuditionSample,
  onClearTrack,
  stepCount
}) => {
  const sampleMap = new Map<string, SampleDefinition>();
  samples.forEach(s => sampleMap.set(s.id, s));

  // Determine if any track is soloed
  const hasSolo = tracks.some(t => t.soloed);

  return (
    <div className="w-full bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Top Bar / Step Indicators Header */}
      <div className="flex items-center border-b border-neutral-800 bg-neutral-950/60 px-3 py-2">
        {/* Track info column header */}
        <div className="w-48 sm:w-56 shrink-0 flex items-center justify-between pr-4 text-[11px] font-mono text-neutral-400 uppercase tracking-wider">
          <span>Track / Sound</span>
          <span className="hidden sm:inline">Mix & Pan</span>
        </div>

        {/* Step Numbers Header */}
        <div className="flex-1 overflow-x-auto no-scrollbar">
          <div className="flex items-center min-w-[560px] gap-1 px-1">
            {Array.from({ length: stepCount }).map((_, stepIdx) => {
              const isMeasureStart = stepIdx % 4 === 0;
              const isCurrent = isPlaying && currentStep === stepIdx;
              const measureNum = Math.floor(stepIdx / 4) + 1;
              const beatInMeasure = (stepIdx % 4) + 1;

              return (
                <div
                  key={stepIdx}
                  className={`flex-1 text-center py-1 rounded transition-colors text-[10px] font-mono select-none ${
                    isCurrent
                      ? 'bg-amber-400 text-neutral-950 font-bold'
                      : isMeasureStart
                      ? 'text-neutral-300 font-semibold'
                      : 'text-neutral-400'
                  }`}
                >
                  {isMeasureStart ? `${measureNum}.${beatInMeasure}` : beatInMeasure}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Track Rows */}
      <div className="divide-y divide-neutral-800/60">
        {tracks.map((track) => {
          const sample = sampleMap.get(track.sampleId);
          if (!sample) return null;

          const isEffectiveMuted = track.muted || (hasSolo && !track.soloed);

          return (
            <div
              key={track.id}
              className={`flex items-center px-3 py-2.5 hover:bg-neutral-800/30 transition-colors ${
                isEffectiveMuted ? 'opacity-40' : 'opacity-100'
              }`}
            >
              {/* Left Column: Sample Controls, Mute/Solo, Faders */}
              <div className="w-48 sm:w-56 shrink-0 flex items-center justify-between pr-3 gap-2">
                {/* Play Trigger & Name */}
                <div className="flex items-center gap-2 min-w-0">
                  <button
                    onClick={() => onAuditionSample(sample)}
                    className="w-7 h-7 shrink-0 rounded-lg flex items-center justify-center border border-neutral-700/80 bg-neutral-800/80 text-white hover:border-amber-400 hover:text-amber-400 transition-colors"
                    title={`Audition ${sample.name} [Key ${sample.keyTrigger}]`}
                  >
                    <Play className="w-3 h-3 fill-current ml-0.5" />
                  </button>

                  <div className="truncate">
                    <p className="text-xs font-medium text-white truncate flex items-center gap-1.5">
                      <span
                        className="w-1.5 h-1.5 rounded-full shrink-0"
                        style={{ backgroundColor: sample.color }}
                      />
                      <span className="truncate">{track.name}</span>
                    </p>
                    <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                      <span>{sample.keyTrigger}</span>
                      <span>·</span>
                      <span className="font-mono text-neutral-300">
                        {track.pitch === 0 ? '0st' : track.pitch > 0 ? `+${track.pitch}st` : `${track.pitch}st`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Mute & Solo Buttons */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => onUpdateTrack(track.id, { muted: !track.muted })}
                    className={`w-6 h-6 rounded text-[10px] font-mono font-bold flex items-center justify-center transition-colors ${
                      track.muted
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/50'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                    title="Mute track"
                  >
                    M
                  </button>

                  <button
                    onClick={() => onUpdateTrack(track.id, { soloed: !track.soloed })}
                    className={`w-6 h-6 rounded text-[10px] font-mono font-bold flex items-center justify-center transition-colors ${
                      track.soloed
                        ? 'bg-amber-400 text-neutral-950 font-extrabold'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                    title="Solo track"
                  >
                    S
                  </button>

                  {/* Pitch Shift Button */}
                  <div className="relative group hidden sm:block">
                    <button
                      className="w-6 h-6 rounded bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center text-[10px] font-mono"
                      title="Adjust Semitone Pitch"
                    >
                      #
                    </button>
                    <div className="absolute left-0 bottom-full mb-1 z-30 hidden group-hover:flex items-center gap-1 p-2 bg-neutral-900 border border-neutral-700 rounded-lg shadow-xl">
                      <button
                        onClick={() => onUpdateTrack(track.id, { pitch: Math.max(-12, track.pitch - 1) })}
                        className="px-1.5 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs"
                      >
                        -
                      </button>
                      <span className="font-mono text-xs text-amber-400 w-8 text-center tabular-nums">
                        {track.pitch}
                      </span>
                      <button
                        onClick={() => onUpdateTrack(track.id, { pitch: Math.min(12, track.pitch + 1) })}
                        className="px-1.5 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Step Grid */}
              <div className="flex-1 overflow-x-auto no-scrollbar">
                <div className="flex items-center min-w-[560px] gap-1 px-1">
                  {Array.from({ length: stepCount }).map((_, stepIdx) => {
                    const isActive = track.steps[stepIdx] || false;
                    const isCurrent = isPlaying && currentStep === stepIdx;
                    const isMeasureStart = stepIdx % 4 === 0;

                    return (
                      <button
                        key={stepIdx}
                        onClick={() => onToggleStep(track.id, stepIdx)}
                        className={`flex-1 h-9 rounded-md transition-all relative flex items-center justify-center select-none active:scale-95 ${
                          isActive
                            ? 'shadow-sm'
                            : isMeasureStart
                            ? 'bg-neutral-800/80 hover:bg-neutral-700/80 border border-neutral-700/50'
                            : 'bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/70'
                        } ${
                          isCurrent
                            ? 'ring-2 ring-white ring-offset-1 ring-offset-neutral-950 z-10'
                            : ''
                        }`}
                        style={{
                          backgroundColor: isActive ? sample.color : undefined
                        }}
                        title={`Step ${stepIdx + 1} (${isActive ? 'Active' : 'Off'})`}
                      >
                        {/* Playhead highlight line */}
                        {isCurrent && (
                          <div className="absolute inset-0 bg-white/30 rounded-md pointer-events-none" />
                        )}
                        {/* Center dot for active beat */}
                        {isActive && (
                          <div className="w-1.5 h-1.5 rounded-full bg-neutral-950/80 shadow-xs" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
